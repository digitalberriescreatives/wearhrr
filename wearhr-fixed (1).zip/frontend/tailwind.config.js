/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      fontFamily: {
        display: ["'Bodoni Moda'", "serif"],
        sans: ["'Chivo'", "sans-serif"],
        body: ["'Manrope'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      colors: {
        ink: {
          0: "#050505",
          1: "#0A0A0A",
          2: "#121212",
          3: "#1a1a1a",
        },
        bone: {
          DEFAULT: "#F5F5F0",
          2: "#EAEAE5",
        },
        muted: {
          dark: "#A3A3A3",
          light: "#525252",
        },
      },
      letterSpacing: {
        widest2: "0.25em",
        widest3: "0.35em",
      },
      transitionTimingFunction: {
        luxe: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
    },
  },
  plugins: [],
};
