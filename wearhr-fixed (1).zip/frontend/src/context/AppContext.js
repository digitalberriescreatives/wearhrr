import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api } from "../lib/api";

const AppCtx = createContext(null);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const [cart, setCart] = useState(() => {
    try { return JSON.parse(localStorage.getItem("wearhr_cart") || "[]"); } catch { return []; }
  });
  const [wishlist, setWishlist] = useState(() => {
    try { return JSON.parse(localStorage.getItem("wearhr_wishlist") || "[]"); } catch { return []; }
  });
  const [cartOpen, setCartOpen] = useState(false);

  useEffect(() => {
    (async () => {
      const token = localStorage.getItem("wearhr_token");
      if (!token) { setReady(true); return; }
      try {
        const { data } = await api.get("/auth/me");
        setUser(data);
      } catch {
        localStorage.removeItem("wearhr_token");
      } finally {
        setReady(true);
      }
    })();
  }, []);

  useEffect(() => { localStorage.setItem("wearhr_cart", JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem("wearhr_wishlist", JSON.stringify(wishlist)); }, [wishlist]);

  const login = useCallback(async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    localStorage.setItem("wearhr_token", data.token);
    setUser(data.user);
    return data.user;
  }, []);
  const register = useCallback(async (email, password, name) => {
    const { data } = await api.post("/auth/register", { email, password, name });
    localStorage.setItem("wearhr_token", data.token);
    setUser(data.user);
    return data.user;
  }, []);
  const logout = useCallback(() => {
    localStorage.removeItem("wearhr_token");
    setUser(null);
  }, []);

  const addToCart = useCallback((product, size, color, qty = 1) => {
    setCart((prev) => {
      const key = `${product.id}|${size}|${color || ""}`;
      const idx = prev.findIndex((i) => `${i.product_id}|${i.size}|${i.color || ""}` === key);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], qty: next[idx].qty + qty };
        return next;
      }
      return [...prev, {
        product_id: product.id,
        title: product.title,
        slug: product.slug,
        image: (product.images || [])[0],
        price: product.price,
        size,
        color,
        qty,
      }];
    });
    setCartOpen(true);
  }, []);
  const updateQty = useCallback((idx, qty) => {
    setCart((prev) => prev.map((it, i) => (i === idx ? { ...it, qty: Math.max(1, qty) } : it)));
  }, []);
  const removeItem = useCallback((idx) => {
    setCart((prev) => prev.filter((_, i) => i !== idx));
  }, []);
  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback((product) => {
    setWishlist((prev) => {
      const exists = prev.find((p) => p.id === product.id);
      if (exists) return prev.filter((p) => p.id !== product.id);
      return [...prev, { id: product.id, title: product.title, slug: product.slug, image: (product.images || [])[0], price: product.price }];
    });
  }, []);

  const value = {
    user, ready, login, register, logout,
    cart, addToCart, updateQty, removeItem, clearCart,
    cartOpen, setCartOpen,
    wishlist, toggleWishlist,
  };
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
