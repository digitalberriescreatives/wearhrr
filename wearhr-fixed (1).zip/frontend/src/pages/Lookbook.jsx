import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import useSEO from "../hooks/useSEO";

const IMAGES = [
  "https://images.unsplash.com/photo-1622866654030-fb0958200023?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.unsplash.com/photo-1609175450590-a969e9318715?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.pexels.com/photos/27516894/pexels-photo-27516894.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1800",
  "https://images.pexels.com/photos/19143887/pexels-photo-19143887.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1800",
  "https://images.pexels.com/photos/5319513/pexels-photo-5319513.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1800",
  "https://images.pexels.com/photos/28701952/pexels-photo-28701952.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1800",
  "https://images.unsplash.com/photo-1613053342567-924891457d16?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.unsplash.com/photo-1532074198010-97d0c3700b7a?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.unsplash.com/photo-1743463685478-d5810b3b1599?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.unsplash.com/photo-1591758203048-4dfd0b546e01?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.unsplash.com/photo-1628411866077-efccc1ba401f?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
  "https://images.unsplash.com/photo-1654512583166-a11eb3b8aa67?crop=entropy&cs=srgb&fm=jpg&q=85&w=1800",
];

export default function Lookbook() {
  useSEO({ title: "Lookbook — WEARHR", description: "The WEARHR lookbook — editorial imagery from the latest collection." });
  return (
    <div className="bg-ink-0 min-h-screen">
      <section className="pt-40 pb-16 md:pb-24 px-6 md:px-10 lg:px-14 max-w-[1800px] mx-auto">
        <div className="eyebrow text-bone/60 mb-4">— SS/26 · EDITORIAL FILM</div>
        <h1 className="hero-display" style={{ fontSize: "clamp(3.5rem, 12vw, 12rem)" }}>The<br/><span className="italic font-normal">Archive.</span></h1>
        <p className="font-body text-bone/60 max-w-2xl mt-8 text-lg">
          A visual doctrine — silhouettes, textures, and the quiet architecture of a wardrobe built for those
          who prefer to be understood, not seen.
        </p>
      </section>

      <section className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14 pb-24">
        <div className="grid grid-cols-12 gap-2 md:gap-4">
          {IMAGES.map((src, i) => {
            const shapes = [
              "col-span-12 md:col-span-8 aspect-[4/3]",
              "col-span-6 md:col-span-4 aspect-[3/4]",
              "col-span-6 md:col-span-4 aspect-[3/4]",
              "col-span-12 md:col-span-8 aspect-[4/3]",
              "col-span-6 md:col-span-6 aspect-[4/5]",
              "col-span-6 md:col-span-6 aspect-[4/5]",
              "col-span-6 md:col-span-4 aspect-[3/4]",
              "col-span-6 md:col-span-4 aspect-[3/4]",
              "col-span-12 md:col-span-4 aspect-[3/4]",
              "col-span-12 md:col-span-6 aspect-[16/10]",
              "col-span-6 md:col-span-3 aspect-[4/5]",
              "col-span-6 md:col-span-3 aspect-[4/5]",
            ];
            return (
              <motion.figure
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-120px" }}
                transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1], delay: (i % 4) * 0.06 }}
                className={`relative overflow-hidden bg-ink-1 group ${shapes[i % shapes.length]}`}
              >
                <img src={src} alt="Editorial" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1800ms]" />
                <figcaption className="absolute bottom-4 left-4 eyebrow text-bone mix-blend-difference opacity-0 group-hover:opacity-100 transition-opacity">LOOK {String(i + 1).padStart(2, "0")}</figcaption>
              </motion.figure>
            );
          })}
        </div>
        <div className="mt-24 flex justify-center">
          <Link to="/shop" className="eyebrow border-b border-bone pb-1 hover:opacity-70">SHOP THE COLLECTION →</Link>
        </div>
      </section>
    </div>
  );
}
