import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import useSEO from "../hooks/useSEO";

const SIZE_CHART = [
  { size: "S", chest: "36–38\"", length: "27\"", shoulder: "17\"" },
  { size: "M", chest: "39–41\"", length: "28\"", shoulder: "18\"" },
  { size: "L", chest: "42–44\"", length: "29\"", shoulder: "19\"" },
  { size: "XL", chest: "45–47\"", length: "30\"", shoulder: "20\"" },
  { size: "XXL", chest: "48–50\"", length: "31\"", shoulder: "21\"" },
];

const PAGES = {
  privacy: {
    title: "Privacy Policy",
    kicker: "— LEGAL",
    sections: [
      ["What we collect", "When you browse WEARHR, create an account, or place an order, we collect the information you give us directly — name, email, phone number, shipping address — along with basic technical data like device type and browsing behaviour on our site, used to keep the storefront working and improve it."],
      ["How we use it", "Your data is used to process orders, manage your account and wishlist, respond to support requests, and — only if you opt in — send you drop announcements and offers. We never sell your personal data to third parties."],
      ["Payments", "Card, UPI, and netbanking payments are processed directly by Razorpay, a licensed payment aggregator. WEARHR does not see or store your card number, CVV, or UPI PIN at any point — that entire step happens on Razorpay's secure, PCI-DSS compliant infrastructure."],
      ["Your rights", "You can request a copy of your data, ask us to correct it, or have your account deleted at any time by writing to privacy@wearhr.in. We'll respond within 7 business days."],
      ["Cookies", "We use essential cookies to keep you logged in and remember your cart, plus optional analytics cookies to understand how the site is used. See our Cookie Policy for details."],
    ],
  },
  terms: {
    title: "Terms of Service",
    kicker: "— LEGAL",
    sections: [
      ["Using this site", "By browsing or purchasing from WEARHR, you agree to these terms. We reserve the right to update them as the brand grows — the current version always applies to any order placed after a change."],
      ["Orders & pricing", "All prices are listed in Indian Rupees (INR) and are inclusive of applicable GST unless stated otherwise. We reserve the right to refuse or cancel any order suspected of fraud, pricing error, or stock unavailability — you'll be refunded in full if this happens."],
      ["Intellectual property", "All designs, photography, and the WEARHR name and mark are the property of Digital Berries / WEARHR. Reproduction without written permission isn't permitted."],
      ["Limitation of liability", "WEARHR is not liable for indirect or consequential loss arising from use of this site, to the maximum extent permitted by Indian law."],
      ["Governing law", "These terms are governed by the laws of India, with courts in Mumbai, Maharashtra having exclusive jurisdiction."],
    ],
  },
  cookies: {
    title: "Cookie Policy",
    kicker: "— LEGAL",
    sections: [
      ["Essential cookies", "These keep you signed in, remember what's in your cart, and let checkout function. The site can't work without these."],
      ["Analytics cookies", "We use privacy-respecting analytics to understand which pages and products get attention, so we can improve the storefront. No personally identifying data is sold or shared with advertisers."],
      ["Managing cookies", "You can clear or block cookies in your browser settings at any time. Blocking essential cookies may prevent checkout and login from working correctly."],
    ],
  },
  shipping: {
    title: "Shipping Policy",
    kicker: "— CLIENT SERVICES",
    sections: [
      ["Processing time", "Orders are processed within 1–2 business days. You'll get a confirmation email the moment your order is placed, and a tracking link the moment it ships."],
      ["Delivery time", "Metro cities: 2–4 business days. Rest of India: 4–7 business days. Remote/rural pin codes may take slightly longer depending on courier coverage."],
      ["Shipping cost", "Free shipping on all prepaid orders above ₹4,999. Below that threshold, a flat ₹199 shipping fee applies."],
      ["International shipping", "We currently ship within India only. International shipping (starting with the UK) is on the roadmap — join the newsletter to be first to know."],
    ],
  },
  returns: {
    title: "Returns & Exchanges",
    kicker: "— CLIENT SERVICES",
    sections: [
      ["Return window", "Unworn, unwashed items with tags attached can be returned within 7 days of delivery for a full refund or exchange."],
      ["How to start a return", "Email returns@wearhr.in with your order number and the item(s) you'd like to return. We'll arrange a reverse pickup where available, or share a return address."],
      ["Refund timeline", "Once we receive and inspect the returned item, refunds are processed to your original payment method within 5–7 business days."],
      ["Non-returnable items", "For hygiene reasons, innerwear, socks, and any item marked \"final sale\" at checkout cannot be returned or exchanged."],
    ],
  },
  "size-guide": {
    title: "Size Guide",
    kicker: "— CLIENT SERVICES",
    sections: [
      ["How to measure", "Chest: measure across the fullest part, under the arms. Length: from the highest point of the shoulder to the hem. Shoulder: seam to seam, across the back."],
    ],
    table: SIZE_CHART,
  },
  help: {
    title: "Help & Contact",
    kicker: "— CLIENT SERVICES",
    sections: [
      ["Order support", "For anything about an existing order — tracking, changes, cancellations — email orders@wearhr.in with your order number and we'll get back within 24 hours."],
      ["General enquiries", "For everything else, reach us at hello@wearhr.in. We're based in Mumbai and typically respond within one business day."],
      ["Wholesale & collaborations", "For stockist enquiries, collaborations, or bulk/corporate orders, write to partnerships@wearhr.in."],
    ],
  },
  careers: {
    title: "Careers",
    kicker: "— HOUSE",
    sections: [
      ["Building something.", "WEARHR is small and growing fast. We're not actively hiring for fixed roles right now, but we're always open to meeting people who care about craft, design, and building a brand the right way."],
      ["Get in touch", "Send a short note and portfolio/CV to careers@wearhr.in — design, ops, and growth backgrounds are all of interest."],
    ],
  },
  press: {
    title: "Press",
    kicker: "— HOUSE",
    sections: [
      ["For media", "For interview requests, product loans, or brand assets, email press@wearhr.in and we'll get back to you promptly."],
      ["Brand assets", "A press kit with logo files and approved imagery is available on request — just let us know what you're working on."],
    ],
  },
  sustainability: {
    title: "Sustainability",
    kicker: "— HOUSE",
    sections: [
      ["Built to last", "WEARHR is built on heavyweight fabrics and considered construction specifically so pieces last seasons, not weeks — the most sustainable garment is the one you don't need to replace."],
      ["Where we're headed", "We're actively working toward better-sourced cotton, reduced packaging waste, and clearer supply chain transparency as we scale. This page will grow as those commitments become concrete."],
    ],
  },
};

export default function InfoPage({ slug }) {
  const page = PAGES[slug];

  useSEO({
    title: page ? `${page.title} — WEARHR` : "WEARHR",
    description: page ? `${page.title} for WEARHR — Wear Your Ambition.` : undefined,
  });

  if (!page) {
    return (
      <div className="pt-40 pb-40 text-center bg-ink-0 min-h-screen">
        <h1 className="section-display mb-6">Page not found.</h1>
        <Link to="/" className="eyebrow underline">RETURN HOME</Link>
      </div>
    );
  }

  return (
    <div className="pt-28 md:pt-40 pb-24 bg-ink-0 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-[900px] mx-auto px-6 md:px-10"
      >
        <div className="eyebrow text-bone/50 mb-6">{page.kicker}</div>
        <h1 className="section-display leading-none mb-14">{page.title}</h1>

        <div className="space-y-10">
          {page.sections.map(([h, body]) => (
            <div key={h}>
              <h2 className="font-display text-xl md:text-2xl italic mb-3">{h}</h2>
              <p className="font-body text-bone/70 leading-relaxed">{body}</p>
            </div>
          ))}
        </div>

        {page.table && (
          <div className="mt-14 border border-bone/15 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="eyebrow text-bone/60 bg-ink-1">
                  <th className="text-left px-4 py-3">SIZE</th>
                  <th className="text-left px-4 py-3">CHEST</th>
                  <th className="text-left px-4 py-3">LENGTH</th>
                  <th className="text-left px-4 py-3">SHOULDER</th>
                </tr>
              </thead>
              <tbody>
                {page.table.map((row) => (
                  <tr key={row.size} className="border-t border-bone/10 font-mono">
                    <td className="px-4 py-3">{row.size}</td>
                    <td className="px-4 py-3">{row.chest}</td>
                    <td className="px-4 py-3">{row.length}</td>
                    <td className="px-4 py-3">{row.shoulder}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-16 pt-8 border-t border-bone/10">
          <Link to="/" className="eyebrow underline underline-offset-4 hover:text-bone/70">RETURN HOME</Link>
        </div>
      </motion.div>
    </div>
  );
}
