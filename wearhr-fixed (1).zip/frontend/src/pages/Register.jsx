import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";
import useSEO from "../hooks/useSEO";

export default function Register() {
  useSEO({ title: "Create Account — WEARHR", noindex: true });
  const { register } = useApp();
  const nav = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      await register(form.email, form.password, form.name);
      nav("/account");
    } catch (e) {
      setErr(e.response?.data?.detail || "Registration failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      <div className="flex flex-col items-center justify-center p-8 md:p-16 bg-ink-0 order-2 md:order-1">
        <div className="w-full max-w-sm">
          <div className="eyebrow text-bone/60 mb-4">— JOIN THE HOUSE</div>
          <h1 className="font-display text-4xl md:text-5xl mb-10">Create<br/><span className="italic font-normal">an account.</span></h1>
          <form onSubmit={submit} className="space-y-6">
            <input data-testid="reg-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Full name" className="w-full bg-transparent border-b border-bone/20 py-3 focus:outline-none focus:border-bone" />
            <input data-testid="reg-email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email" className="w-full bg-transparent border-b border-bone/20 py-3 focus:outline-none focus:border-bone" />
            <input data-testid="reg-password" type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Password (min 6 characters)" className="w-full bg-transparent border-b border-bone/20 py-3 focus:outline-none focus:border-bone" />
            {err && <p data-testid="reg-error" className="text-red-400 eyebrow text-xs">{err}</p>}
            <button data-testid="reg-submit" type="submit" disabled={busy} className="w-full bg-bone text-ink-0 py-4 eyebrow hover:bg-bone/85 disabled:opacity-50">
              {busy ? "CREATING…" : "CREATE ACCOUNT"}
            </button>
          </form>
          <p className="mt-8 font-body text-sm text-bone/60">
            Already a member? <Link to="/login" className="text-bone underline underline-offset-4">Sign in</Link>
          </p>
        </div>
      </div>
      <div className="hidden md:block relative bg-ink-1 order-1 md:order-2">
        <img src="/assets/hero-hussain.jpg" alt="WEARHR" className="w-full h-full object-cover opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-ink-0" />
        <Link to="/" className="absolute top-8 right-8 font-display text-2xl">WEARHR</Link>
        <div className="absolute bottom-8 left-8 right-8">
          <div className="eyebrow text-bone/60 mb-2">— MEMBERS PRIVILEGE</div>
          <p className="font-display text-3xl italic">Early access. Private drops.<br/>The full archive.</p>
        </div>
      </div>
    </div>
  );
}
