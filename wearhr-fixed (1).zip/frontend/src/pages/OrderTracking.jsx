import React, { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { api, formatINR } from "../lib/api";
import { CheckCircle2, Package, Truck, Home } from "lucide-react";

export default function OrderTracking() {
  const [params] = useSearchParams();
  const id = params.get("id");
  const [order, setOrder] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    if (!id) { setErr("No order specified."); return; }
    (async () => {
      try {
        const { data } = await api.get(`/orders/${id}`);
        setOrder(data.order);
      } catch (e) {
        setErr(e.response?.data?.detail || "Order not found.");
      }
    })();
  }, [id]);

  if (err) {
    return (
      <div className="pt-40 pb-40 text-center bg-ink-0 min-h-screen">
        <h1 className="section-display mb-6">{err}</h1>
        <Link to="/" data-testid="ordertracking-home" className="eyebrow underline underline-offset-8">RETURN HOME</Link>
      </div>
    );
  }
  if (!order) return <div className="pt-40 text-center font-body text-bone/50 bg-ink-0 min-h-screen">Locating your order…</div>;

  const steps = [
    { key: "created", l: "PLACED", icon: CheckCircle2 },
    { key: "confirmed", l: "CONFIRMED", icon: Package },
    { key: "shipped", l: "SHIPPED", icon: Truck },
    { key: "delivered", l: "DELIVERED", icon: Home },
  ];
  const statusIdx = Math.max(0, steps.findIndex((s) => s.key === order.status));

  return (
    <div className="pt-28 md:pt-32 pb-24 bg-ink-0 min-h-screen">
      <div className="max-w-[1200px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="eyebrow text-bone/60 mb-6">— ORDER TRACKING</div>
        <h1 className="section-display leading-none mb-4">
          {order.payment_status === "paid" ? "Thank you." : "Almost there."}
        </h1>
        <p className="font-body text-bone/60 mb-2">Order #{order.id.slice(-8).toUpperCase()}</p>
        <p className="eyebrow text-bone/50 mb-16">STATUS · {order.status?.toUpperCase()} · PAYMENT · {order.payment_status?.toUpperCase()}</p>

        <div className="grid grid-cols-4 gap-4 mb-20">
          {steps.map((s, i) => {
            const Icon = s.icon;
            const active = i <= statusIdx;
            return (
              <div key={s.key} className={`border p-6 ${active ? "border-bone bg-bone/5" : "border-bone/15 opacity-50"}`}>
                <Icon size={22} className="mb-3" />
                <div className="eyebrow">{s.l}</div>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-12 gap-12">
          <div className="col-span-12 md:col-span-7">
            <h2 className="eyebrow mb-4">ITEMS</h2>
            <ul className="divide-y divide-bone/10 border-y border-bone/10">
              {order.items?.map((it, i) => (
                <li key={i} className="py-4 flex gap-4">
                  <img src={it.image} alt={it.title} className="w-16 h-20 object-cover bg-ink-1" />
                  <div className="flex-1">
                    <div className="text-sm">{it.title}</div>
                    <div className="eyebrow text-bone/50">{it.size} · x{it.qty}</div>
                  </div>
                  <div className="font-mono text-sm">{formatINR(it.line_total)}</div>
                </li>
              ))}
            </ul>
          </div>
          <div className="col-span-12 md:col-span-5">
            <h2 className="eyebrow mb-4">SUMMARY</h2>
            <div className="font-mono text-sm space-y-2 border-t border-bone/10 pt-4">
              <div className="flex justify-between"><span className="text-bone/60">Subtotal</span><span>{formatINR(order.subtotal)}</span></div>
              <div className="flex justify-between"><span className="text-bone/60">Shipping</span><span>{order.shipping === 0 ? "Free" : formatINR(order.shipping)}</span></div>
              <div className="flex justify-between"><span className="text-bone/60">Tax</span><span>{formatINR(order.tax)}</span></div>
              <div className="flex justify-between text-lg pt-3 border-t border-bone/10 mt-3"><span>Total</span><span>{formatINR(order.total)}</span></div>
            </div>
            {order.address && (
              <div className="mt-8">
                <h3 className="eyebrow mb-3">SHIPPING TO</h3>
                <p className="font-body text-bone/70 text-sm leading-relaxed">
                  {order.address.full_name}<br/>
                  {order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ""}<br/>
                  {order.address.city}, {order.address.state} {order.address.postal_code}<br/>
                  {order.address.country}<br/>
                  <span className="text-bone/50">{order.address.phone} · {order.address.email}</span>
                </p>
              </div>
            )}
          </div>
        </div>
        <div className="mt-16">
          <Link to="/shop" className="eyebrow border-b border-bone/40 pb-1 hover:opacity-70">CONTINUE SHOPPING →</Link>
        </div>
      </div>
    </div>
  );
}
