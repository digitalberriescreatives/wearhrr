import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Heart, Truck, RefreshCcw, ShieldCheck, Ruler, ChevronDown } from "lucide-react";
import { api, formatINR } from "../lib/api";
import { fallbackProducts } from "../lib/fallbackData";
import { useApp } from "../context/AppContext";
import MagneticButton from "../components/MagneticButton";
import ProductCard from "../components/ProductCard";
import useSEO from "../hooks/useSEO";

function fallbackDetail(slug) {
  const pool = fallbackProducts(8, { tag: "featured" });
  const product = pool.find((p) => p.slug === slug) || {
    ...pool[0],
    slug,
    title: "Heavyweight Piece",
  };
  return {
    product: {
      ...product,
      description: "Heavyweight cotton. Editorial cut. Zero excess — the discipline WEARHR is built on.",
      sizes: ["S", "M", "L", "XL", "XXL"],
      colors: ["Obsidian", "Bone"],
      materials: ["Premium heavyweight cotton"],
      fit: "Oversized fit",
      care: "Cold wash inside out.",
    },
    related: fallbackProducts(4, { tag: "related" }),
  };
}

export default function ProductDetail() {
  const { slug } = useParams();
  const { addToCart, toggleWishlist, wishlist } = useApp();
  const [data, setData] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [openSection, setOpenSection] = useState("materials");
  const [error, setError] = useState("");

  useEffect(() => {
    setData(null);
    setNotFound(false);
    (async () => {
      try {
        const { data } = await api.get(`/products/${slug}`);
        setData(data);
        setSize(data.product.sizes?.[0] || "");
        setColor(data.product.colors?.[0] || "");
      } catch (e) {
        if (e.response?.status === 404) {
          setNotFound(true);
        } else {
          // Backend unreachable — show a graceful placeholder rather than
          // spinning forever, so the page is always navigable.
          const fb = fallbackDetail(slug);
          setData(fb);
          setSize(fb.product.sizes?.[0] || "");
          setColor(fb.product.colors?.[0] || "");
        }
      }
    })();
    window.scrollTo({ top: 0 });
  }, [slug]);

  useSEO({
    title: data ? `${data.product.title} — WEARHR` : "WEARHR",
    description: data ? (data.product.description || `${data.product.title} — available now at WEARHR.`) : undefined,
    image: data?.product?.images?.[0],
  });

  if (notFound) {
    return (
      <div className="pt-40 pb-40 text-center bg-ink-0 min-h-screen">
        <h1 className="section-display mb-6">Piece not found.</h1>
        <Link to="/shop" data-testid="pdp-notfound-shop" className="eyebrow underline">RETURN TO THE ARCHIVE</Link>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="pt-24 md:pt-28 pb-24 bg-ink-0 min-h-screen">
        <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14 grid grid-cols-12 gap-4 md:gap-16 animate-pulse">
          <div className="col-span-12 md:col-span-7 aspect-[4/5] bg-ink-1 shimmer" />
          <div className="col-span-12 md:col-span-5 space-y-4">
            <div className="h-4 w-24 bg-ink-1 shimmer" />
            <div className="h-14 w-3/4 bg-ink-1 shimmer" />
            <div className="h-4 w-1/3 bg-ink-1 shimmer" />
            <div className="h-24 w-full bg-ink-1 shimmer" />
          </div>
        </div>
      </div>
    );
  }
  const p = data.product;
  const inWishlist = wishlist.some((w) => w.id === p.id);

  const handleAdd = () => {
    if (!size) { setError("Choose a size."); return; }
    setError("");
    addToCart(p, size, color, 1);
  };

  return (
    <div className="pt-24 md:pt-28 pb-24 bg-ink-0 min-h-screen">
      <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
        {/* Breadcrumb */}
        <div className="eyebrow text-bone/50 mb-8">
          <Link to="/">HOME</Link> / <Link to="/shop">SHOP</Link> / <Link to={`/shop/${p.category}`}>{p.category?.toUpperCase()}</Link>
        </div>

        <div className="grid grid-cols-12 gap-4 md:gap-16">
          {/* IMAGES */}
          <div className="col-span-12 md:col-span-7 space-y-2 md:space-y-4">
            {(p.images || []).map((src, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
                className="relative overflow-hidden bg-ink-1 aspect-[4/5]"
              >
                <img src={src} alt={p.title} className="w-full h-full object-cover" />
              </motion.div>
            ))}
          </div>

          {/* DETAILS — sticky */}
          <div className="col-span-12 md:col-span-5">
            <div className="md:sticky md:top-28">
              <div className="eyebrow text-bone/50 mb-4">{p.category?.toUpperCase()}</div>
              <h1 className="font-display text-4xl md:text-6xl leading-[0.95] tracking-tight mb-6">{p.title}</h1>
              <div className="flex items-baseline gap-3 mb-8">
                <span className="font-mono text-xl">{formatINR(p.price)}</span>
                {p.compare_at_price && <span className="font-mono text-sm line-through text-bone/40">{formatINR(p.compare_at_price)}</span>}
                {p.compare_at_price && <span className="eyebrow bg-bone text-ink-0 px-2 py-0.5">MEMBERS PRICE</span>}
              </div>

              <p className="font-body text-bone/75 text-lg leading-relaxed mb-10">{p.description}</p>

              {/* Color */}
              {p.colors?.length > 0 && (
                <div className="mb-8">
                  <div className="eyebrow text-bone/60 mb-3">COLOR · {color}</div>
                  <div className="flex gap-2">
                    {p.colors.map((c) => (
                      <button
                        key={c}
                        data-testid={`color-${c}`}
                        onClick={() => setColor(c)}
                        className={`px-4 py-2 border ${color === c ? "border-bone bg-bone text-ink-0" : "border-bone/25 hover:border-bone"}`}
                      >
                        <span className="eyebrow">{c}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Size */}
              {p.sizes?.length > 0 && (
                <div className="mb-8">
                  <div className="flex justify-between items-center eyebrow text-bone/60 mb-3">
                    <span>SIZE</span>
                    <button className="flex items-center gap-2 hover:text-bone"><Ruler size={12} /> SIZE GUIDE</button>
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    {p.sizes.map((s) => (
                      <button
                        key={s}
                        data-testid={`size-${s}`}
                        onClick={() => setSize(s)}
                        className={`py-3 border eyebrow ${size === s ? "border-bone bg-bone text-ink-0" : "border-bone/25 hover:border-bone"}`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {error && <p data-testid="pdp-error" className="text-red-400 text-xs eyebrow mb-4">{error}</p>}

              {/* Actions */}
              <div className="flex gap-3 mb-10">
                <MagneticButton testid="add-to-cart-btn" onClick={handleAdd} className="flex-1 bg-bone text-ink-0 py-5 eyebrow hover:bg-bone/85">
                  ADD TO BAG · {formatINR(p.price)}
                </MagneticButton>
                <button
                  data-testid="pdp-wishlist-btn"
                  onClick={() => toggleWishlist(p)}
                  className="w-16 border border-bone/25 flex items-center justify-center hover:border-bone"
                  aria-label="Wishlist"
                >
                  <Heart size={18} fill={inWishlist ? "#F5F5F0" : "transparent"} />
                </button>
              </div>

              {/* Trust bar */}
              <div className="grid grid-cols-3 border-t border-b border-bone/10 py-4 mb-8">
                <div className="flex flex-col items-center text-center gap-1"><Truck size={16} /><span className="eyebrow text-bone/60">FREE SHIP OVER ₹4999</span></div>
                <div className="flex flex-col items-center text-center gap-1 border-x border-bone/10"><RefreshCcw size={16} /><span className="eyebrow text-bone/60">30-DAY RETURNS</span></div>
                <div className="flex flex-col items-center text-center gap-1"><ShieldCheck size={16} /><span className="eyebrow text-bone/60">CRAFTED BY HAND</span></div>
              </div>

              {/* Accordion */}
              {[
                { key: "materials", label: "MATERIALS", body: p.materials?.length ? p.materials.map((m, i) => <li key={i}>{m}</li>) : <li>Premium heavyweight cotton.</li> },
                { key: "fit", label: "FIT & CARE", body: <><li>{p.fit || "Oversized fit"}</li><li>{p.care || "Cold wash inside out."}</li></> },
                { key: "shipping", label: "SHIPPING & RETURNS", body: <><li>Free shipping on orders above ₹4,999 (India).</li><li>International: 5–9 business days.</li><li>30-day free returns on unworn pieces.</li></> },
              ].map((s) => (
                <div key={s.key} className="border-t border-bone/10">
                  <button
                    data-testid={`accordion-${s.key}`}
                    onClick={() => setOpenSection(openSection === s.key ? "" : s.key)}
                    className="w-full flex items-center justify-between py-5 eyebrow"
                  >
                    <span>{s.label}</span>
                    <ChevronDown size={14} className={`transition-transform ${openSection === s.key ? "rotate-180" : ""}`} />
                  </button>
                  {openSection === s.key && (
                    <ul className="pb-5 font-body text-bone/70 text-sm space-y-1 list-disc list-inside">{s.body}</ul>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RELATED */}
        {data.related?.length > 0 && (
          <section className="mt-28 md:mt-40" data-testid="related-section">
            <div className="mb-12">
              <div className="eyebrow text-bone/60 mb-3">— YOU MAY ALSO WANT</div>
              <h2 className="section-display">Continue the story.</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
              {data.related.map((r, i) => <ProductCard key={r.id} product={r} index={i} />)}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
