import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import useSEO from "../hooks/useSEO";

export default function Story() {
  useSEO({ title: "Our Story — WEARHR", description: "The story behind WEARHR — designed in Mumbai, built for ambition." });
  return (
    <div className="bg-ink-0 min-h-screen">
      <section className="pt-40 pb-20 md:pb-28 px-6 md:px-10 lg:px-14 max-w-[1800px] mx-auto grain">
        <div className="eyebrow text-bone/60 mb-4">— THE HOUSE OF WEARHR</div>
        <h1 className="hero-display" style={{ fontSize: "clamp(3.5rem, 12vw, 12rem)" }}>
          The<br/><span className="italic font-normal">Doctrine.</span>
        </h1>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 md:px-10 lg:px-14 pb-16">
        <div className="grid grid-cols-12 gap-8 md:gap-16">
          <div className="col-span-12 md:col-span-6">
            <img src="/assets/hero-hussain.jpg" alt="Hussain, Founder WEARHR" className="w-full aspect-[4/5] object-cover bg-ink-1" />
            <p className="eyebrow text-bone/50 mt-4">HUSSAIN, FOUNDER · MUMBAI · 2026</p>
          </div>
          <div className="col-span-12 md:col-span-6 md:pt-16">
            <blockquote className="font-display italic text-3xl md:text-5xl leading-tight text-bone">
              "We do not chase trends. We build a wardrobe that outlasts them."
            </blockquote>
            <div className="mt-10 space-y-6 font-body text-bone/75 text-lg leading-relaxed">
              <p>WEARHR was born in a small studio in Mumbai, from a single conviction — that the clothes we wear should carry the same discipline as the work we do.</p>
              <p>Heavyweight cotton, sourced from Portugal. Editorial silhouettes, drafted by hand. Every seam locked. Every wash controlled. Zero excess.</p>
              <p>We ship globally, from Milan to Tokyo, but every piece begins in the same Mumbai atelier. This is not fast fashion. This is not slow fashion. This is a doctrine.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pillars */}
      <section className="py-24 md:py-40 max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14 border-t border-bone/10">
        <div className="eyebrow text-bone/60 mb-6">— THE THREE PILLARS</div>
        <h2 className="section-display mb-16">Craft, cut,<br/><span className="italic font-normal">consequence.</span></h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            { n: "01", t: "MATERIAL", b: "320–500 GSM heavyweight cotton. Portugal-woven, Mumbai-cut, garment-washed for a first-day-worn softness that ages with you." },
            { n: "02", t: "CUT", b: "Editorial silhouettes drafted with the discipline of tailoring. Dropped shoulders, engineered rib, elongated hems." },
            { n: "03", t: "CONSEQUENCE", b: "Every piece traceable. Every yard accounted for. We measure our footprint the way we measure our seams." },
          ].map((p, i) => (
            <motion.div key={p.n} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.9, delay: i * 0.1 }}>
              <div className="font-mono text-bone/40 mb-4">{p.n}</div>
              <h3 className="font-display text-4xl mb-4">{p.t}</h3>
              <p className="font-body text-bone/70 leading-relaxed">{p.b}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-24 border-t border-bone/10">
        <div className="max-w-[1400px] mx-auto text-center px-6">
          <Link data-testid="story-shop-cta" to="/shop" className="font-display text-4xl md:text-6xl italic border-b border-bone/40 pb-2 inline-block hover:opacity-80">Enter the archive →</Link>
        </div>
      </section>
    </div>
  );
}
