import React from "react";
import { Link } from "react-router-dom";
import { Heart, Trash2 } from "lucide-react";
import { useApp } from "../context/AppContext";
import { formatINR } from "../lib/api";
import useSEO from "../hooks/useSEO";

export default function Wishlist() {
  useSEO({ title: "Wishlist — WEARHR", noindex: true });
  const { wishlist, toggleWishlist } = useApp();
  return (
    <div className="pt-28 md:pt-36 pb-24 bg-ink-0 min-h-screen">
      <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="eyebrow text-bone/60 mb-6">— WISHLIST</div>
        <h1 className="section-display mb-12">Kept<br/><span className="italic font-normal">for later.</span></h1>
        {wishlist.length === 0 ? (
          <div className="text-center py-24">
            <p className="font-body text-bone/60 mb-6">No pieces saved yet.</p>
            <Link to="/shop" className="eyebrow underline underline-offset-8">EXPLORE THE COLLECTION →</Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
            {wishlist.map((w) => (
              <div key={w.id} className="group relative" data-testid={`wishlist-card-${w.id}`}>
                <Link to={`/product/${w.slug}`} className="block">
                  <div className="aspect-[4/5] overflow-hidden bg-ink-1">
                    <img src={w.image} alt={w.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1200ms]" />
                  </div>
                  <div className="mt-4 flex justify-between text-sm">
                    <span className="truncate">{w.title}</span>
                    <span className="font-mono">{formatINR(w.price)}</span>
                  </div>
                </Link>
                <button
                  data-testid={`wishlist-remove-${w.id}`}
                  onClick={() => toggleWishlist(w)}
                  className="absolute top-4 right-4 w-9 h-9 bg-ink-0/80 backdrop-blur-sm flex items-center justify-center hover:bg-bone hover:text-ink-0"
                  aria-label="Remove"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
