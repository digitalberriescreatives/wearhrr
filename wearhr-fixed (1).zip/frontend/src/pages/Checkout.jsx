import React, { useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { api, formatINR } from "../lib/api";
import { useApp } from "../context/AppContext";
import useSEO from "../hooks/useSEO";

export default function Checkout() {
  useSEO({ title: "Checkout — WEARHR", noindex: true });
  const { cart, clearCart, user } = useApp();
  const nav = useNavigate();
  const [addr, setAddr] = useState({
    full_name: user?.name || "",
    email: user?.email || "",
    phone: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    postal_code: "",
    country: "India",
  });
  const [method, setMethod] = useState("razorpay");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const subtotal = useMemo(() => cart.reduce((a, i) => a + i.price * i.qty, 0), [cart]);
  const shipping = subtotal >= 4999 ? 0 : 199;
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + shipping + tax;

  if (cart.length === 0) {
    return (
      <div className="pt-40 pb-40 text-center">
        <h1 className="section-display mb-6">Bag is empty.</h1>
        <Link to="/shop" data-testid="checkout-empty-shop" className="eyebrow underline">RETURN TO SHOP</Link>
      </div>
    );
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      const items = cart.map((i) => ({ product_id: i.product_id, size: i.size, color: i.color, qty: i.qty }));
      const { data } = await api.post("/orders", { items, address: addr, method });
      const order = data.order;

      if (method === "cod") {
        clearCart();
        nav(`/order-tracking?id=${order.id}`);
        return;
      }

      // Razorpay
      if (typeof window.Razorpay !== "function") {
        setErr("Payment gateway couldn't load (check your connection or ad-blocker) — try Cash on Delivery instead.");
        setBusy(false);
        return;
      }
      const options = {
        key: data.razorpay_key_id,
        amount: order.total * 100,
        currency: "INR",
        name: "WEARHR",
        description: "Wear Your Ambition",
        order_id: order.razorpay_order_id,
        prefill: {
          name: addr.full_name,
          email: addr.email,
          contact: addr.phone,
        },
        theme: { color: "#050505" },
        handler: async (resp) => {
          try {
            await api.post("/orders/verify", {
              order_id: order.id,
              razorpay_order_id: resp.razorpay_order_id,
              razorpay_payment_id: resp.razorpay_payment_id,
              razorpay_signature: resp.razorpay_signature,
            });
            clearCart();
            nav(`/order-tracking?id=${order.id}`);
          } catch (e) {
            setErr("Payment verification failed. Please contact us.");
          }
        },
        modal: { ondismiss: () => setBusy(false) },
      };
      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", () => setErr("Payment failed. Try again."));
      rzp.open();
    } catch (e) {
      setErr(e.response?.data?.detail || "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  const inp = "w-full bg-transparent border-b border-bone/20 py-3 focus:outline-none focus:border-bone placeholder:text-bone/40";

  return (
    <div className="pt-28 md:pt-32 pb-24 bg-ink-0 min-h-screen">
      <div className="max-w-[1400px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="eyebrow text-bone/60 mb-6">— CHECKOUT</div>
        <h1 className="section-display mb-12">The<br/><span className="italic font-normal">final step.</span></h1>

        <form onSubmit={onSubmit} className="grid grid-cols-12 gap-12">
          <div className="col-span-12 md:col-span-7 space-y-10">
            <div>
              <h2 className="eyebrow mb-6">01 · CONTACT</h2>
              <div className="grid grid-cols-2 gap-4">
                <input data-testid="checkout-name" required value={addr.full_name} onChange={(e) => setAddr({ ...addr, full_name: e.target.value })} placeholder="Full name" className={inp} />
                <input data-testid="checkout-phone" required value={addr.phone} onChange={(e) => setAddr({ ...addr, phone: e.target.value })} placeholder="Phone" className={inp} />
                <input data-testid="checkout-email" required type="email" value={addr.email} onChange={(e) => setAddr({ ...addr, email: e.target.value })} placeholder="Email" className={inp + " col-span-2"} />
              </div>
            </div>
            <div>
              <h2 className="eyebrow mb-6">02 · SHIPPING ADDRESS</h2>
              <div className="grid grid-cols-2 gap-4">
                <input data-testid="checkout-line1" required value={addr.line1} onChange={(e) => setAddr({ ...addr, line1: e.target.value })} placeholder="Address line 1" className={inp + " col-span-2"} />
                <input value={addr.line2} onChange={(e) => setAddr({ ...addr, line2: e.target.value })} placeholder="Address line 2 (optional)" className={inp + " col-span-2"} />
                <input data-testid="checkout-city" required value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} placeholder="City" className={inp} />
                <input data-testid="checkout-state" required value={addr.state} onChange={(e) => setAddr({ ...addr, state: e.target.value })} placeholder="State" className={inp} />
                <input data-testid="checkout-zip" required value={addr.postal_code} onChange={(e) => setAddr({ ...addr, postal_code: e.target.value })} placeholder="PIN code" className={inp} />
                <input value={addr.country} onChange={(e) => setAddr({ ...addr, country: e.target.value })} placeholder="Country" className={inp} />
              </div>
            </div>
            <div>
              <h2 className="eyebrow mb-6">03 · PAYMENT METHOD</h2>
              <div className="grid grid-cols-2 gap-3">
                <label className={`border p-4 cursor-pointer ${method === "razorpay" ? "border-bone" : "border-bone/25"}`}>
                  <input type="radio" name="pm" data-testid="pm-razorpay" checked={method === "razorpay"} onChange={() => setMethod("razorpay")} className="mr-2" />
                  <span className="eyebrow">RAZORPAY · CARD · UPI · NET BANKING</span>
                </label>
                <label className={`border p-4 cursor-pointer ${method === "cod" ? "border-bone" : "border-bone/25"}`}>
                  <input type="radio" name="pm" data-testid="pm-cod" checked={method === "cod"} onChange={() => setMethod("cod")} className="mr-2" />
                  <span className="eyebrow">CASH ON DELIVERY</span>
                </label>
              </div>
            </div>
            {err && <p data-testid="checkout-error" className="text-red-400 eyebrow">{err}</p>}
          </div>

          <aside className="col-span-12 md:col-span-5 md:sticky md:top-28 md:self-start">
            <div className="border border-bone/15 p-6 md:p-8">
              <h2 className="eyebrow mb-6">ORDER SUMMARY</h2>
              <ul className="space-y-4 mb-6 max-h-72 overflow-y-auto pr-2">
                {cart.map((it, i) => (
                  <li key={i} className="flex gap-3">
                    <img src={it.image} alt={it.title} className="w-16 h-20 object-cover bg-ink-1" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm truncate">{it.title}</div>
                      <div className="eyebrow text-bone/50">{it.size} · x{it.qty}</div>
                    </div>
                    <div className="font-mono text-sm">{formatINR(it.price * it.qty)}</div>
                  </li>
                ))}
              </ul>
              <div className="border-t border-bone/10 pt-4 space-y-2 font-mono text-sm">
                <div className="flex justify-between"><span className="text-bone/60">Subtotal</span><span>{formatINR(subtotal)}</span></div>
                <div className="flex justify-between"><span className="text-bone/60">Shipping</span><span>{shipping === 0 ? "Free" : formatINR(shipping)}</span></div>
                <div className="flex justify-between"><span className="text-bone/60">Tax (5%)</span><span>{formatINR(tax)}</span></div>
                <div className="flex justify-between text-lg pt-3 border-t border-bone/10 mt-3"><span>Total</span><span>{formatINR(total)}</span></div>
              </div>
              <button data-testid="place-order-btn" type="submit" disabled={busy} className="w-full mt-6 bg-bone text-ink-0 py-4 eyebrow hover:bg-bone/85 disabled:opacity-50">
                {busy ? "PROCESSING…" : method === "cod" ? `PLACE ORDER · ${formatINR(total)}` : `PAY · ${formatINR(total)}`}
              </button>
              <p className="eyebrow text-bone/40 mt-4 text-center">SECURED BY RAZORPAY</p>
            </div>
          </aside>
        </form>
      </div>
    </div>
  );
}
