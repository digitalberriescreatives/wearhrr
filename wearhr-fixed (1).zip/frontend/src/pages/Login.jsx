import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";
import useSEO from "../hooks/useSEO";

export default function Login() {
  useSEO({ title: "Sign In — WEARHR", noindex: true });
  const { login } = useApp();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      await login(email, password);
      nav("/account");
    } catch (e) {
      setErr(e.response?.data?.detail || "Login failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      <div className="hidden md:block relative bg-ink-1">
        <img src="/assets/hero-hussain.jpg" alt="WEARHR" className="w-full h-full object-cover opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-ink-0" />
        <Link to="/" className="absolute top-8 left-8 font-display text-2xl">WEARHR</Link>
        <div className="absolute bottom-8 left-8 right-8">
          <div className="eyebrow text-bone/60 mb-2">— MEMBERS ONLY</div>
          <p className="font-display text-3xl italic">The inner circle awaits.</p>
        </div>
      </div>
      <div className="flex flex-col items-center justify-center p-8 md:p-16 bg-ink-0">
        <div className="w-full max-w-sm">
          <Link to="/" className="md:hidden font-display text-2xl block mb-12">WEARHR</Link>
          <div className="eyebrow text-bone/60 mb-4">— SIGN IN</div>
          <h1 className="font-display text-4xl md:text-5xl mb-10">Welcome<br/><span className="italic font-normal">back.</span></h1>
          <form onSubmit={submit} className="space-y-6">
            <input data-testid="login-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full bg-transparent border-b border-bone/20 py-3 focus:outline-none focus:border-bone" />
            <input data-testid="login-password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="w-full bg-transparent border-b border-bone/20 py-3 focus:outline-none focus:border-bone" />
            {err && <p data-testid="login-error" className="text-red-400 eyebrow text-xs">{err}</p>}
            <button data-testid="login-submit" type="submit" disabled={busy} className="w-full bg-bone text-ink-0 py-4 eyebrow hover:bg-bone/85 disabled:opacity-50">
              {busy ? "SIGNING IN…" : "SIGN IN"}
            </button>
          </form>
          <p className="mt-8 font-body text-sm text-bone/60">
            New to WEARHR? <Link data-testid="login-to-register" to="/register" className="text-bone underline underline-offset-4">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
