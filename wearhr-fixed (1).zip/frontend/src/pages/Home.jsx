import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, ArrowUpRight, Play } from "lucide-react";
import { api, formatINR } from "../lib/api";
import { fallbackProducts } from "../lib/fallbackData";
import SplitText from "../components/SplitText";
import MagneticButton from "../components/MagneticButton";
import ProductCard from "../components/ProductCard";
import { SkeletonCard } from "../components/Skeleton";
import useSEO from "../hooks/useSEO";

const LOOKBOOK = [
  "https://images.unsplash.com/photo-1622866654030-fb0958200023?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
  "https://images.unsplash.com/photo-1609175450590-a969e9318715?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
  "https://images.pexels.com/photos/27516894/pexels-photo-27516894.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
  "https://images.pexels.com/photos/19143887/pexels-photo-19143887.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
  "https://images.pexels.com/photos/5319513/pexels-photo-5319513.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
  "https://images.unsplash.com/photo-1654512583166-a11eb3b8aa67?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
];

export default function Home() {
  useSEO({ title: "WEARHR — Wear Your Ambition", description: "Premium streetwear designed in Mumbai. Heavyweight cotton, considered cuts, shipped across India." });
  const [featured, setFeatured] = useState([]);
  const [newDrop, setNewDrop] = useState([]);
  const [bestSellers, setBestSellers] = useState([]);
  const [loading, setLoading] = useState(true);

  const { scrollYProgress } = useScroll();
  const heroImgY = useTransform(scrollYProgress, [0, 0.15], ["0%", "12%"]);
  const heroImgScale = useTransform(scrollYProgress, [0, 0.15], [1, 1.08]);

  useEffect(() => {
    (async () => {
      try {
        const [a, b, c] = await Promise.all([
          api.get("/products", { params: { featured: true, limit: 8 } }),
          api.get("/products", { params: { new_drop: true, limit: 6 } }),
          api.get("/products", { params: { best_seller: true, limit: 8 } }),
        ]);
        setFeatured(a.data.items?.length ? a.data.items : fallbackProducts(8, { tag: "featured" }));
        setNewDrop(b.data.items?.length ? b.data.items : fallbackProducts(6, { tag: "new", newDrop: true }));
        setBestSellers(c.data.items?.length ? c.data.items : fallbackProducts(8, { tag: "best", bestSeller: true }));
      } catch {
        // Backend unreachable — keep the storefront fully populated with
        // placeholder pieces rather than showing empty sections.
        setFeatured(fallbackProducts(8, { tag: "featured" }));
        setNewDrop(fallbackProducts(6, { tag: "new", newDrop: true }));
        setBestSellers(fallbackProducts(8, { tag: "best", bestSeller: true }));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div>
      {/* HERO — Editorial split with Hussain */}
      <section data-testid="hero-section" className="relative min-h-screen w-full bg-ink-0 overflow-hidden grain">
        <div className="relative z-10 max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14 pt-24 md:pt-28 pb-10 min-h-screen flex flex-col">
          <div className="flex items-center justify-between eyebrow text-bone/60">
            <span>SS/26 · VOL. 001</span>
            <span className="hidden md:inline">A NEW ARCHITECTURE OF DRESS</span>
          </div>

          <div className="flex-1 grid grid-cols-12 gap-6 md:gap-10 items-stretch pt-10 md:pt-14">
            {/* LEFT — MASSIVE TYPE */}
            <div className="col-span-12 md:col-span-7 flex flex-col justify-between">
              <div>
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="eyebrow text-bone/50 mb-4">— THE HOUSE OF WEARHR</motion.div>
                <div className="font-display font-black tracking-tighter leading-[0.85]" style={{ fontSize: "clamp(3.5rem, 11vw, 12rem)" }}>
                  <SplitText text="WEAR" delay={0.3} />
                  <br/>
                  <span className="block"><SplitText text="YOUR" delay={0.45} italic /></span>
                  <span className="block"><SplitText text="AMBITION." delay={0.6} /></span>
                </div>
              </div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.1, duration: 0.9 }} className="mt-10 max-w-md">
                <p className="font-body text-bone/70 text-base md:text-lg leading-relaxed mb-8">
                  Heavyweight cotton. Editorial cuts. An uncompromising discipline of dress — worn by those who build in silence and let the work speak.
                </p>
                <div className="flex items-center gap-3 flex-wrap">
                  <MagneticButton testid="hero-shop-cta" as="a" href="/shop" className="bg-bone text-ink-0 px-8 py-4 eyebrow hover:bg-bone/85 gap-3">
                    ENTER THE HOUSE <ArrowRight size={16} />
                  </MagneticButton>
                  <MagneticButton testid="hero-lookbook-cta" as="a" href="/lookbook" className="border border-bone/40 px-6 py-4 eyebrow hover:bg-bone hover:text-ink-0">
                    LOOKBOOK
                  </MagneticButton>
                </div>
              </motion.div>
            </div>

            {/* RIGHT — HUSSAIN PORTRAIT */}
            <motion.div
              initial={{ opacity: 0, scale: 1.05, clipPath: "inset(100% 0 0 0)" }}
              animate={{ opacity: 1, scale: 1, clipPath: "inset(0% 0 0 0)" }}
              transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1], delay: 0.4 }}
              className="col-span-12 md:col-span-5 relative bg-ink-1 min-h-[50vh] md:min-h-0"
            >
              <motion.img
                src="/assets/hero-hussain.jpg"
                alt="Hussain — the face of WEARHR"
                className="absolute inset-0 w-full h-full object-cover object-[center_20%]"
                style={{ filter: "contrast(1.08) saturate(0.85) brightness(0.98)", y: heroImgY, scale: heroImgScale }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-0/60 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                <div>
                  <div className="eyebrow text-bone/80 mb-1">FACE OF THE HOUSE</div>
                  <div className="font-display italic text-2xl md:text-3xl">Hussain</div>
                </div>
                <div className="font-mono text-xs text-bone/70 text-right leading-tight">MUM<br/>MIL<br/>TYO</div>
              </div>
            </motion.div>
          </div>

          <div className="mt-10 md:mt-14 flex items-end justify-between border-t border-bone/15 pt-5">
            <div className="eyebrow text-bone/50 max-w-xs">SCROLL — 07 CHAPTERS · 50 PIECES · ONE DOCTRINE</div>
            <motion.div animate={{ y: [0, 8, 0] }} transition={{ repeat: Infinity, duration: 2 }} className="w-px h-12 bg-bone/40" />
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <section className="border-y border-bone/10 py-6 overflow-hidden">
        <div className="marquee-track font-display text-4xl md:text-6xl">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex items-center gap-16">
              <span>WEARHR</span><span className="italic text-bone/40">— WEAR YOUR AMBITION</span>
              <span>WEARHR</span><span className="italic text-bone/40">— NEW DROP LIVE</span>
              <span>WEARHR</span><span className="italic text-bone/40">— MUMBAI · MILAN · TOKYO</span>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED COLLECTION */}
      <section data-testid="featured-section" className="py-28 md:py-40 px-6 md:px-10 lg:px-14 max-w-[1800px] mx-auto">
        <div className="flex items-end justify-between mb-16 md:mb-24 gap-6">
          <div>
            <div className="eyebrow text-bone/60 mb-4">— CHAPTER 01</div>
            <h2 className="section-display">The Featured<br/><span className="italic font-normal">Collection.</span></h2>
          </div>
          <Link data-testid="featured-view-all" to="/shop" className="eyebrow text-bone/70 hover:text-bone hidden md:inline-flex items-center gap-2">VIEW ALL <ArrowUpRight size={14} /></Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8">
          {loading ? (
            Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)
          ) : (
            featured.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)
          )}
        </div>
      </section>

      {/* NEW DROP — inverted */}
      <section data-testid="newdrop-section" className="bg-bone text-ink-0 py-28 md:py-40">
        <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
          <div className="flex items-end justify-between mb-16 md:mb-24">
            <div>
              <div className="eyebrow text-ink-0/60 mb-4">— CHAPTER 02 · NEW DROP</div>
              <h2 className="section-display">Fresh<br/>from the atelier.</h2>
            </div>
            <Link data-testid="newdrop-view-all" to="/shop?new_drop=true" className="eyebrow hover:opacity-60 hidden md:inline-flex items-center gap-2">SHOP THE DROP <ArrowRight size={14} /></Link>
          </div>
          <div className="grid grid-cols-12 gap-4 md:gap-8">
            {loading ? (
              <>
                <div className="col-span-12 md:col-span-8 aspect-[4/3] bg-ink-0/10 shimmer" />
                <div className="col-span-12 md:col-span-4 grid grid-cols-2 md:grid-cols-1 gap-4 md:gap-8">
                  <div className="aspect-[4/5] bg-ink-0/10 shimmer" />
                  <div className="aspect-[4/5] bg-ink-0/10 shimmer" />
                </div>
              </>
            ) : (
            <>
            {newDrop[0] && (
              <Link data-testid="newdrop-hero" to={`/product/${newDrop[0].slug}`} className="col-span-12 md:col-span-8 group">
                <div className="relative aspect-[4/3] overflow-hidden bg-ink-1">
                  <img src={newDrop[0].images?.[0]} alt={newDrop[0].title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1500ms] ease-luxe" />
                  <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                    <div>
                      <div className="eyebrow text-bone mix-blend-difference">JUST DROPPED</div>
                      <div className="font-display italic text-3xl md:text-5xl text-bone mix-blend-difference">{newDrop[0].title}</div>
                    </div>
                    <div className="font-mono text-bone mix-blend-difference">{formatINR(newDrop[0].price)}</div>
                  </div>
                </div>
              </Link>
            )}
            <div className="col-span-12 md:col-span-4 grid grid-cols-2 md:grid-cols-1 gap-4 md:gap-8">
              {newDrop.slice(1, 3).map((p) => (
                <Link key={p.id} to={`/product/${p.slug}`} className="group">
                  <div className="relative aspect-[4/5] overflow-hidden bg-ink-1">
                    <img src={p.images?.[0]} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1500ms] ease-luxe" />
                  </div>
                  <div className="mt-3 flex justify-between text-sm">
                    <span className="truncate">{p.title}</span>
                    <span className="font-mono">{formatINR(p.price)}</span>
                  </div>
                </Link>
              ))}
            </div>
            </>
            )}
          </div>
        </div>
      </section>

      {/* CAMPAIGN VIDEO */}
      <section data-testid="campaign-section" className="relative bg-ink-0 py-24 md:py-32 grain">
        <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
          <div className="eyebrow text-bone/60 mb-4">— CHAPTER 03 · CAMPAIGN FILM</div>
          <h2 className="section-display mb-12">A doctrine of<br/><span className="italic font-normal">quiet power.</span></h2>
          <div className="relative aspect-[16/9] w-full overflow-hidden bg-ink-1 group cursor-pointer">
            <img src={LOOKBOOK[5]} alt="Campaign film" className="w-full h-full object-cover opacity-70 group-hover:opacity-90 transition-opacity duration-700" />
            <div className="absolute inset-0 flex items-center justify-center">
              <MagneticButton testid="play-campaign" className="w-24 h-24 md:w-32 md:h-32 border border-bone rounded-full bg-ink-0/40 backdrop-blur-sm">
                <Play size={32} fill="#F5F5F0" />
              </MagneticButton>
            </div>
            <div className="absolute bottom-6 left-6 right-6 flex justify-between eyebrow text-bone">
              <span>WEARHR · SS/26 CAMPAIGN</span>
              <span>02:38</span>
            </div>
          </div>
        </div>
      </section>

      {/* BRAND STORY */}
      <section data-testid="story-section" className="bg-ink-0 py-28 md:py-40 border-t border-bone/10">
        <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14 grid grid-cols-12 gap-8 md:gap-16">
          <div className="col-span-12 md:col-span-7">
            <div className="eyebrow text-bone/60 mb-6">— CHAPTER 04 · THE DOCTRINE</div>
            <h2 className="section-display italic font-normal">"Dress like the person you are becoming."</h2>
            <div className="mt-10 font-display text-2xl text-bone/70 max-w-xl">— HUSSAIN, FOUNDER</div>
          </div>
          <div className="col-span-12 md:col-span-5 md:pt-10">
            <p className="font-body text-bone/70 text-lg leading-relaxed mb-6">
              WEARHR was born in a small studio in Mumbai in 2026, from a single conviction — that the clothes we wear
              should carry the same discipline as the work we do. Heavyweight cotton. Editorial silhouettes. Zero excess.
            </p>
            <p className="font-body text-bone/70 text-lg leading-relaxed mb-8">
              Every piece is drafted, sampled, and washed in-house. We do not chase trends. We build a wardrobe that outlasts them.
            </p>
            <Link data-testid="story-cta" to="/story" className="eyebrow inline-flex items-center gap-2 border-b border-bone pb-1 hover:opacity-70">READ THE FULL STORY <ArrowRight size={14} /></Link>
          </div>
        </div>
      </section>

      {/* BEST SELLERS */}
      <section data-testid="bestsellers-section" className="py-28 md:py-40 px-6 md:px-10 lg:px-14 max-w-[1800px] mx-auto border-t border-bone/10">
        <div className="flex items-end justify-between mb-16 md:mb-24">
          <div>
            <div className="eyebrow text-bone/60 mb-4">— CHAPTER 05 · THE CLASSICS</div>
            <h2 className="section-display">Worn by<br/><span className="italic font-normal">a generation.</span></h2>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8">
          {loading ? (
            Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)
          ) : (
            bestSellers.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)
          )}
        </div>
      </section>

      {/* EDITORIAL LOOKBOOK — Bento */}
      <section data-testid="lookbook-section" className="bg-ink-1 py-28 md:py-40">
        <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
          <div className="flex items-end justify-between mb-16">
            <div>
              <div className="eyebrow text-bone/60 mb-4">— CHAPTER 06 · EDITORIAL</div>
              <h2 className="section-display">The lookbook.</h2>
            </div>
            <Link data-testid="lookbook-cta" to="/lookbook" className="eyebrow hover:opacity-70 hidden md:inline-flex items-center gap-2">VIEW ALL <ArrowUpRight size={14} /></Link>
          </div>
          <div className="grid grid-cols-12 gap-2 md:gap-4">
            {LOOKBOOK.slice(0, 6).map((src, i) => {
              const spans = [
                "col-span-12 md:col-span-8 md:row-span-2 aspect-[4/5] md:aspect-[3/4]",
                "col-span-6 md:col-span-4 aspect-[4/5]",
                "col-span-6 md:col-span-4 aspect-[4/5]",
                "col-span-12 md:col-span-6 aspect-[16/10]",
                "col-span-6 md:col-span-3 aspect-[4/5]",
                "col-span-6 md:col-span-3 aspect-[4/5]",
              ];
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: i * 0.08 }}
                  className={`relative overflow-hidden bg-ink-0 group ${spans[i]}`}
                >
                  <img src={src} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1800ms] ease-luxe" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* PRESS / REVIEWS MARQUEE */}
      <section data-testid="press-section" className="border-t border-bone/10 py-12 overflow-hidden">
        <div className="marquee-track eyebrow text-2xl md:text-4xl text-bone/60 font-mono">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex gap-16 items-center">
              <span>"THE NEW STANDARD OF STREETWEAR"</span><span className="text-bone/30">— VOGUE INDIA</span>
              <span>"AN ARCHITECT'S CLOSET."</span><span className="text-bone/30">— HYPEBEAST</span>
              <span>"QUIETLY REDEFINING LUXURY."</span><span className="text-bone/30">— GQ</span>
              <span>"THE BRAND TO WATCH IN 2026."</span><span className="text-bone/30">— WWD</span>
            </div>
          ))}
        </div>
      </section>

      {/* INSTAGRAM GRID */}
      <section data-testid="instagram-section" className="py-28 md:py-40 max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="flex items-end justify-between mb-12">
          <div>
            <div className="eyebrow text-bone/60 mb-4">— CHAPTER 07 · @WEARHR</div>
            <h2 className="section-display">Field notes.</h2>
          </div>
          <a href="https://instagram.com/wearhr" target="_blank" rel="noreferrer" className="eyebrow hover:opacity-70 hidden md:inline-flex items-center gap-2">FOLLOW <ArrowUpRight size={14} /></a>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 md:gap-3">
          {LOOKBOOK.slice(0, 6).map((src, i) => (
            <a key={i} href="https://instagram.com/wearhr" target="_blank" rel="noreferrer" className="relative aspect-square overflow-hidden bg-ink-1 group">
              <img src={src} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
