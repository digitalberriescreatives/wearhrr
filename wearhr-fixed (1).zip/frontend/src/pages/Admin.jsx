import React, { useEffect, useState, useCallback } from "react";
import { Link } from "react-router-dom";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { useApp } from "../context/AppContext";
import { api, formatINR } from "../lib/api";
import ProductForm from "../components/admin/ProductForm";
import useSEO from "../hooks/useSEO";

const TABS = [
  { key: "overview", label: "OVERVIEW" },
  { key: "products", label: "PRODUCTS" },
  { key: "orders", label: "ORDERS" },
  { key: "users", label: "USERS" },
];

export default function Admin() {
  useSEO({ title: "Admin — WEARHR", noindex: true });
  const { user } = useApp();
  const [tab, setTab] = useState("overview");

  if (!user) return <div className="pt-40 text-center bg-ink-0 min-h-screen"><Link to="/login" className="underline">Sign in</Link> to access admin.</div>;
  if (user.role !== "admin") return <div className="pt-40 text-center font-body text-bone/60 bg-ink-0 min-h-screen">Admin access only.</div>;

  return (
    <div className="pt-28 md:pt-36 pb-24 bg-ink-0 min-h-screen">
      <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="eyebrow text-bone/60 mb-6">— ADMIN CONSOLE</div>
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <h1 className="section-display leading-none">The<br/><span className="italic font-normal">house dashboard.</span></h1>
          <div className="flex gap-1 border border-bone/15">
            {TABS.map((t) => (
              <button
                key={t.key}
                data-testid={`admin-tab-${t.key}`}
                onClick={() => setTab(t.key)}
                className={`eyebrow px-5 py-3 transition-colors ${tab === t.key ? "bg-bone text-ink-0" : "hover:bg-bone/10"}`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {tab === "overview" && <AdminOverview />}
        {tab === "products" && <AdminProducts />}
        {tab === "orders" && <AdminOrders />}
        {tab === "users" && <AdminUsers />}
      </div>
    </div>
  );
}

function AdminOverview() {
  const [stats, setStats] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get("/admin/stats");
        setStats(data);
      } catch (e) {
        setErr(e.response?.data?.detail || "Could not load stats.");
      }
    })();
  }, []);
  return (
    <div>
      {err && <p className="text-red-400 eyebrow mb-6">{err}</p>}
      {stats ? (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-16">
          <Stat l="ORDERS" v={stats.orders} />
          <Stat l="PAID" v={stats.paid} />
          <Stat l="REVENUE" v={formatINR(stats.revenue)} />
          <Stat l="PRODUCTS" v={stats.products} />
          <Stat l="USERS" v={stats.users} />
        </div>
      ) : !err ? (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-16 animate-pulse">
          {Array.from({ length: 5 }).map((_, i) => <div key={i} className="border border-bone/10 p-6 h-24 shimmer" />)}
        </div>
      ) : null}
    </div>
  );
}

function Stat({ l, v }) {
  return (
    <div className="border border-bone/10 p-6">
      <div className="eyebrow text-bone/60 mb-3">{l}</div>
      <div className="font-display text-3xl">{v}</div>
    </div>
  );
}

function AdminProducts() {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [editing, setEditing] = useState(null); // product being edited, or {} for new
  const [deleting, setDeleting] = useState(null);

  const load = useCallback(async (query = "") => {
    setLoading(true); setErr("");
    try {
      const { data } = await api.get("/admin/products", { params: { limit: 200, q: query || undefined } });
      setItems(data.items);
    } catch (e) {
      setErr(e.response?.data?.detail || "Could not load products. Are you signed in as admin?");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const onSearch = (e) => {
    e.preventDefault();
    load(q);
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await api.delete(`/admin/products/${deleting.id}`);
      setDeleting(null);
      load(q);
    } catch (e) {
      setErr(e.response?.data?.detail || "Could not delete product.");
      setDeleting(null);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <form onSubmit={onSearch} className="flex items-center gap-2 border border-bone/20 px-4 py-2 max-w-sm w-full">
          <Search size={14} className="text-bone/40" />
          <input
            data-testid="admin-product-search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search products by title…"
            className="bg-transparent flex-1 focus:outline-none placeholder:text-bone/40 text-sm"
          />
        </form>
        <button
          data-testid="admin-add-product"
          onClick={() => setEditing({})}
          className="inline-flex items-center gap-2 eyebrow bg-bone text-ink-0 px-6 py-3 hover:bg-bone/85"
        >
          <Plus size={14} /> ADD PRODUCT
        </button>
      </div>

      {err && <p data-testid="admin-products-error" className="text-red-400 eyebrow mb-6">{err}</p>}

      <div className="border border-bone/10 overflow-x-auto">
        <div className="min-w-[800px]">
          <div className="grid grid-cols-12 eyebrow bg-ink-1 px-4 py-3 text-bone/60">
            <div className="col-span-4">PRODUCT</div>
            <div className="col-span-2">CATEGORY</div>
            <div className="col-span-2">PRICE</div>
            <div className="col-span-2">STOCK</div>
            <div className="col-span-2 text-right">ACTIONS</div>
          </div>
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="grid grid-cols-12 px-4 py-4 border-t border-bone/10 items-center animate-pulse">
                <div className="col-span-12 h-6 bg-ink-1 shimmer" />
              </div>
            ))
          ) : items.length === 0 ? (
            <div className="p-10 text-center text-bone/50 font-body">No products found.</div>
          ) : (
            items.map((p) => (
              <div key={p.id} className="grid grid-cols-12 px-4 py-4 border-t border-bone/10 items-center text-sm" data-testid={`admin-product-row-${p.id}`}>
                <div className="col-span-4 flex items-center gap-3 min-w-0">
                  <img src={p.images?.[0]} alt="" className="w-10 h-12 object-cover bg-ink-1 flex-shrink-0" />
                  <span className="truncate">{p.title}</span>
                  {p.featured && <span className="eyebrow text-[9px] text-bone/40 flex-shrink-0">F</span>}
                  {p.new_drop && <span className="eyebrow text-[9px] text-bone/40 flex-shrink-0">N</span>}
                </div>
                <div className="col-span-2 eyebrow text-bone/60">{p.category}</div>
                <div className="col-span-2 font-mono">
                  {formatINR(p.price)}
                  {p.compare_at_price && <span className="text-bone/40 line-through ml-2 text-xs">{formatINR(p.compare_at_price)}</span>}
                </div>
                <div className="col-span-2 font-mono">{p.stock ?? "—"}</div>
                <div className="col-span-2 flex justify-end gap-3">
                  <button data-testid={`admin-edit-${p.id}`} onClick={() => setEditing(p)} aria-label="Edit" className="hover:text-bone/60"><Pencil size={16} /></button>
                  <button data-testid={`admin-delete-${p.id}`} onClick={() => setDeleting(p)} aria-label="Delete" className="hover:text-red-400"><Trash2 size={16} /></button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {editing !== null && (
        <ProductForm
          product={editing.id ? editing : null}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); load(q); }}
        />
      )}

      {deleting && (
        <div className="fixed inset-0 z-[90] bg-ink-0/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-ink-0 border border-bone/15 max-w-sm w-full p-8 text-center">
            <h3 className="font-display text-2xl mb-4">Remove this piece?</h3>
            <p className="font-body text-bone/60 mb-8">"{deleting.title}" will be permanently deleted from the archive.</p>
            <div className="flex gap-3">
              <button data-testid="admin-confirm-delete" onClick={confirmDelete} className="flex-1 bg-bone text-ink-0 py-3 eyebrow hover:bg-bone/85">DELETE</button>
              <button onClick={() => setDeleting(null)} className="flex-1 border border-bone/25 py-3 eyebrow hover:border-bone">CANCEL</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get("/admin/users");
        setUsers(data.items);
      } catch (e) {
        setErr(e.response?.data?.detail || "Access denied.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div>
      {err && <p className="text-red-400 eyebrow mb-6">{err}</p>}
      <div className="border border-bone/10 overflow-x-auto">
        <div className="min-w-[700px]">
          <div className="grid grid-cols-12 eyebrow bg-ink-1 px-4 py-3 text-bone/60">
            <div className="col-span-4">NAME</div>
            <div className="col-span-4">EMAIL</div>
            <div className="col-span-2">ROLE</div>
            <div className="col-span-2">JOINED</div>
          </div>
          {loading ? (
            Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-12 border-t border-bone/10 shimmer" />)
          ) : users.length === 0 ? (
            <div className="p-8 text-center text-bone/50 font-body">No users yet.</div>
          ) : users.map((u) => (
            <div key={u.id} className="grid grid-cols-12 px-4 py-4 border-t border-bone/10 items-center text-sm">
              <div className="col-span-4 truncate">{u.name || "—"}</div>
              <div className="col-span-4 truncate text-bone/70">{u.email}</div>
              <div className="col-span-2 eyebrow text-bone/60">{u.role?.toUpperCase()}</div>
              <div className="col-span-2 font-mono text-bone/50 text-xs">{u.created_at ? new Date(u.created_at).toLocaleDateString() : "—"}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get("/admin/orders");
        setOrders(data.items);
      } catch (e) {
        setErr(e.response?.data?.detail || "Access denied.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div>
      {err && <p className="text-red-400 eyebrow mb-6">{err}</p>}
      <div className="border border-bone/10 overflow-x-auto">
        <div className="min-w-[700px]">
          <div className="grid grid-cols-12 eyebrow bg-ink-1 px-4 py-3 text-bone/60">
            <div className="col-span-3">ORDER</div>
            <div className="col-span-3">EMAIL</div>
            <div className="col-span-2">STATUS</div>
            <div className="col-span-2">PAYMENT</div>
            <div className="col-span-2 text-right">TOTAL</div>
          </div>
          {loading ? (
            Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-12 border-t border-bone/10 shimmer" />)
          ) : orders.length === 0 ? (
            <div className="p-8 text-center text-bone/50 font-body">No orders yet.</div>
          ) : orders.map((o) => (
            <div key={o.id} className="grid grid-cols-12 px-4 py-4 border-t border-bone/10 items-center text-sm">
              <div className="col-span-3 font-mono">#{o.id.slice(-8).toUpperCase()}</div>
              <div className="col-span-3 truncate text-bone/70">{o.email}</div>
              <div className="col-span-2 eyebrow">{o.status?.toUpperCase()}</div>
              <div className="col-span-2 eyebrow text-bone/60">{o.payment_status?.toUpperCase()}</div>
              <div className="col-span-2 font-mono text-right">{formatINR(o.total)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
