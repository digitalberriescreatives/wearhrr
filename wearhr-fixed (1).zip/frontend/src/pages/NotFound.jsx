import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-ink-0 px-6 text-center grain">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="eyebrow text-bone/50 mb-6">— CHAPTER 404</div>
        <h1 className="hero-display leading-none" style={{ fontSize: "clamp(4rem, 16vw, 14rem)" }}>
          Lost<br /><span className="italic font-normal">the thread.</span>
        </h1>
        <p className="font-body text-bone/60 max-w-md mx-auto mt-8 mb-10 text-lg">
          This page isn't part of the archive. Let's get you back to the collection.
        </p>
        <Link
          data-testid="notfound-home-cta"
          to="/"
          className="inline-flex items-center gap-3 eyebrow bg-bone text-ink-0 px-8 py-4 hover:bg-bone/85"
        >
          RETURN HOME <ArrowRight size={16} />
        </Link>
      </motion.div>
    </div>
  );
}
