import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../context/AppContext";
import { api, formatINR } from "../lib/api";
import useSEO from "../hooks/useSEO";

export default function Account() {
  useSEO({ title: "My Account — WEARHR", noindex: true });
  const { user, logout } = useApp();
  const [orders, setOrders] = useState([]);
  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const { data } = await api.get("/orders");
        setOrders(data.items);
      } catch {}
    })();
  }, [user]);
  if (!user) {
    return (
      <div className="pt-40 pb-40 text-center">
        <p className="mb-4">Please sign in.</p>
        <Link to="/login" className="eyebrow underline">SIGN IN</Link>
      </div>
    );
  }
  return (
    <div className="pt-28 md:pt-36 pb-24 bg-ink-0 min-h-screen">
      <div className="max-w-[1400px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="eyebrow text-bone/60 mb-6">— ACCOUNT</div>
        <div className="flex items-end justify-between mb-16">
          <h1 className="section-display leading-none">Hello, <span className="italic font-normal">{user.name?.split(" ")[0] || user.email}</span>.</h1>
          <div className="flex items-center gap-6">
            {user.role === "admin" && (
              <Link data-testid="account-admin-link" to="/admin" className="eyebrow border-b border-bone/40 hover:text-bone/70">ADMIN CONSOLE</Link>
            )}
            <button data-testid="logout-btn" onClick={logout} className="eyebrow border-b border-bone/40 hover:text-bone/70">SIGN OUT</button>
          </div>
        </div>
        <div className="grid grid-cols-12 gap-12">
          <div className="col-span-12 md:col-span-4">
            <h2 className="eyebrow mb-4">PROFILE</h2>
            <div className="font-body text-bone/70 space-y-2">
              <p>{user.name}</p>
              <p className="text-bone/50">{user.email}</p>
              <p className="eyebrow text-bone/40 mt-4">MEMBER · {user.role?.toUpperCase()}</p>
            </div>
          </div>
          <div className="col-span-12 md:col-span-8">
            <h2 className="eyebrow mb-4">ORDER HISTORY</h2>
            {orders.length === 0 ? (
              <p className="font-body text-bone/50">No orders yet. <Link to="/shop" className="underline text-bone">Browse the archive →</Link></p>
            ) : (
              <ul className="divide-y divide-bone/10 border-y border-bone/10">
                {orders.map((o) => (
                  <li key={o.id} className="py-6 flex items-center justify-between" data-testid={`order-row-${o.id}`}>
                    <div>
                      <div className="font-mono text-sm">#{o.id.slice(-8).toUpperCase()}</div>
                      <div className="eyebrow text-bone/50 mt-1">{new Date(o.created_at).toLocaleDateString()} · {o.items?.length} items · {o.status?.toUpperCase()}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono">{formatINR(o.total)}</div>
                      <Link to={`/order-tracking?id=${o.id}`} className="eyebrow underline underline-offset-4 text-bone/70 hover:text-bone">TRACK</Link>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
