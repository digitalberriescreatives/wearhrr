import React, { useEffect, useState, useMemo } from "react";
import { useParams, useSearchParams, Link } from "react-router-dom";
import { api } from "../lib/api";
import { fallbackProducts } from "../lib/fallbackData";
import ProductCard from "../components/ProductCard";
import { SkeletonCard } from "../components/Skeleton";
import { ChevronDown } from "lucide-react";
import useSEO from "../hooks/useSEO";

const SORTS = [
  { v: "featured", l: "Featured" },
  { v: "newest", l: "Newest" },
  { v: "price_asc", l: "Price: Low → High" },
  { v: "price_desc", l: "Price: High → Low" },
];

const CATS = [
  { v: "", l: "All" },
  { v: "tees", l: "Tees" },
  { v: "hoodies", l: "Hoodies" },
  { v: "sweatshirts", l: "Sweatshirts" },
  { v: "jackets", l: "Outerwear" },
  { v: "cargos", l: "Bottoms" },
  { v: "joggers", l: "Joggers" },
  { v: "denim", l: "Denim" },
  { v: "caps", l: "Caps" },
  { v: "accessories", l: "Accessories" },
];

export default function Shop() {
  useSEO({ title: "Shop All — WEARHR", description: "Browse the full WEARHR collection — tees, hoodies, outerwear, denim, caps and accessories." });
  const { category } = useParams();
  const [params, setParams] = useSearchParams();
  const q = params.get("q") || "";
  const newDrop = params.get("new_drop");
  const [items, setItems] = useState([]);
  const [sort, setSort] = useState(params.get("sort") || "featured");
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    (async () => {
      try {
        const p = { sort, limit: 60 };
        if (category) p.category = category;
        if (q) p.q = q;
        if (newDrop) p.new_drop = true;
        const { data } = await api.get("/products", { params: p });
        if (data.items?.length) {
          setItems(data.items);
          setTotal(data.total);
        } else {
          const fb = fallbackProducts(12, { tag: category || "shop" });
          setItems(fb);
          setTotal(fb.length);
        }
      } catch {
        const fb = fallbackProducts(12, { tag: category || "shop" });
        setItems(fb);
        setTotal(fb.length);
      } finally {
        setLoading(false);
      }
    })();
  }, [category, q, newDrop, sort]);

  const title = useMemo(() => {
    if (q) return `Search: "${q}"`;
    const c = CATS.find((x) => x.v === category);
    return c ? c.l : "All Products";
  }, [q, category]);

  return (
    <div className="pt-28 md:pt-36 pb-24 min-h-screen bg-ink-0">
      <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
        <div className="flex items-end justify-between mb-10 md:mb-16 gap-6">
          <div>
            <div className="eyebrow text-bone/60 mb-4">— THE ARCHIVE</div>
            <h1 className="section-display leading-none">{title}</h1>
            <div className="eyebrow text-bone/50 mt-4">{total} PIECES</div>
          </div>
          <div className="hidden md:flex items-center gap-3">
            <span className="eyebrow text-bone/50">SORT</span>
            <div className="relative">
              <select
                data-testid="sort-select"
                value={sort}
                onChange={(e) => { setSort(e.target.value); params.set("sort", e.target.value); setParams(params); }}
                className="appearance-none bg-transparent border border-bone/20 px-4 py-2 pr-10 eyebrow focus:outline-none focus:border-bone"
              >
                {SORTS.map((s) => <option key={s.v} value={s.v} className="bg-ink-0">{s.l}</option>)}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-8">
          <aside className="col-span-12 md:col-span-2">
            <div className="eyebrow text-bone/60 mb-4">CATEGORIES</div>
            <ul className="space-y-2">
              {CATS.map((c) => {
                const active = (c.v || "") === (category || "");
                return (
                  <li key={c.v}>
                    <Link
                      data-testid={`filter-cat-${c.v || 'all'}`}
                      to={c.v ? `/shop/${c.v}` : "/shop"}
                      className={`block font-body text-sm py-1 hover:opacity-70 ${active ? "text-bone" : "text-bone/60"}`}
                    >
                      {c.l}{active && " ·"}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </aside>
          <div className="col-span-12 md:col-span-10">
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
                {Array.from({ length: 9 }).map((_, i) => <SkeletonCard key={i} />)}
              </div>
            ) : items.length === 0 ? (
              <div className="py-24 text-center text-bone/50 font-body">No pieces found. Try another lens.</div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
                {items.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
