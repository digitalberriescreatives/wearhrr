import { useEffect } from "react";
import { useLocation } from "react-router-dom";

// Cinematic momentum scrolling (mandated by design guidelines).
// Fails silently if the `lenis` package isn't installed yet so the app
// never breaks — it just falls back to native scroll.
export default function useLenis() {
  const { pathname } = useLocation();

  useEffect(() => {
    let lenis;
    let rafId;
    let cancelled = false;

    (async () => {
      try {
        const mod = await import("lenis");
        if (cancelled) return;
        const Lenis = mod.default;
        lenis = new Lenis({
          duration: 1.15,
          easing: (t) => 1 - Math.pow(1 - t, 3),
          smoothWheel: true,
          wheelMultiplier: 1,
          touchMultiplier: 1.1,
        });
        const raf = (time) => {
          lenis.raf(time);
          rafId = requestAnimationFrame(raf);
        };
        rafId = requestAnimationFrame(raf);
        window.__lenis = lenis;
      } catch {
        // lenis not installed — native scroll is the graceful fallback
      }
    })();

    return () => {
      cancelled = true;
      if (rafId) cancelAnimationFrame(rafId);
      if (lenis) lenis.destroy();
      window.__lenis = undefined;
    };
  }, []);

  // Scroll to top with the same easing on every route change.
  useEffect(() => {
    if (window.__lenis) {
      window.__lenis.scrollTo(0, { immediate: true });
    } else {
      window.scrollTo({ top: 0 });
    }
  }, [pathname]);
}
