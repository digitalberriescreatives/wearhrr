import { useEffect } from "react";

function setMeta(name, content, attr = "name") {
  if (!content) return;
  let tag = document.querySelector(`meta[${attr}="${name}"]`);
  if (!tag) {
    tag = document.createElement("meta");
    tag.setAttribute(attr, name);
    document.head.appendChild(tag);
  }
  tag.setAttribute("content", content);
}

function setCanonical(url) {
  let link = document.querySelector('link[rel="canonical"]');
  if (!link) {
    link = document.createElement("link");
    link.setAttribute("rel", "canonical");
    document.head.appendChild(link);
  }
  link.setAttribute("href", url);
}

// Lightweight per-page SEO: sets document title, meta description, Open
// Graph tags, and canonical URL on mount. No react-helmet dependency —
// this is a client-rendered app, so search engines that execute JS
// (Google) will still see this; for maximum indexing/ranking, pairing
// this with server-side rendering (e.g. migrating to Next.js) or
// prerendering is the next step, plus real content, backlinks and time —
// no amount of meta tags alone guarantees a #1 ranking.
export default function useSEO({ title, description, image, noindex = false }) {
  useEffect(() => {
    const fullTitle = title || "WEARHR — Wear Your Ambition";
    document.title = fullTitle;

    setMeta("description", description || "WEARHR — premium streetwear and editorial essentials designed in Mumbai. Heavyweight cotton, considered cuts, shipped across India.");
    setMeta("robots", noindex ? "noindex, nofollow" : "index, follow");

    setMeta("og:title", fullTitle, "property");
    setMeta("og:description", description, "property");
    setMeta("og:type", "website", "property");
    setMeta("og:url", window.location.href, "property");
    if (image) setMeta("og:image", image, "property");

    setMeta("twitter:card", "summary_large_image");
    setMeta("twitter:title", fullTitle);
    setMeta("twitter:description", description);

    setCanonical(window.location.origin + window.location.pathname);
  }, [title, description, image, noindex]);
}
