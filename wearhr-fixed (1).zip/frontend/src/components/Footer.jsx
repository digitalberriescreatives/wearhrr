import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import { Instagram, Twitter, Youtube } from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const subscribe = async (e) => {
    e.preventDefault();
    if (!email) return;
    try { await api.post("/newsletter", { email }); setSent(true); } catch {}
  };
  return (
    <footer data-testid="site-footer" className="bg-ink-0 text-bone border-t border-bone/10">
      <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14 pt-24 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-8">
          <div className="md:col-span-5">
            <div className="eyebrow text-bone/60 mb-4">— NEWSLETTER</div>
            <h3 className="section-display leading-none mb-8">Join the<br/><span className="italic font-normal">inner circle.</span></h3>
            {sent ? (
              <p data-testid="newsletter-thanks" className="font-body text-bone/70 text-lg">Welcome — first-access invites are on their way.</p>
            ) : (
              <form onSubmit={subscribe} className="flex border-b border-bone/30 max-w-md" data-testid="newsletter-form">
                <input
                  data-testid="newsletter-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  className="bg-transparent flex-1 py-4 focus:outline-none placeholder:text-bone/40"
                />
                <button data-testid="newsletter-submit" type="submit" className="eyebrow hover:text-bone/70">SUBSCRIBE →</button>
              </form>
            )}
          </div>

          <div className="md:col-span-2">
            <div className="eyebrow text-bone/60 mb-6">SHOP</div>
            <ul className="space-y-3 font-body text-sm">
              <li><Link data-testid="footer-tees" to="/shop/tees" className="hover:opacity-60">T-Shirts</Link></li>
              <li><Link data-testid="footer-hoodies" to="/shop/hoodies" className="hover:opacity-60">Hoodies</Link></li>
              <li><Link to="/shop/jackets" className="hover:opacity-60">Outerwear</Link></li>
              <li><Link to="/shop/denim" className="hover:opacity-60">Denim</Link></li>
              <li><Link to="/shop/cargos" className="hover:opacity-60">Bottoms</Link></li>
              <li><Link to="/shop/caps" className="hover:opacity-60">Caps</Link></li>
              <li><Link to="/shop/accessories" className="hover:opacity-60">Accessories</Link></li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <div className="eyebrow text-bone/60 mb-6">HOUSE</div>
            <ul className="space-y-3 font-body text-sm">
              <li><Link to="/story" className="hover:opacity-60">Our Story</Link></li>
              <li><Link to="/lookbook" className="hover:opacity-60">Lookbook</Link></li>
              <li><Link to="/press" className="hover:opacity-60">Press</Link></li>
              <li><Link to="/careers" className="hover:opacity-60">Careers</Link></li>
              <li><Link to="/sustainability" className="hover:opacity-60">Sustainability</Link></li>
            </ul>
          </div>

          <div className="md:col-span-3">
            <div className="eyebrow text-bone/60 mb-6">CLIENT SERVICES</div>
            <ul className="space-y-3 font-body text-sm">
              <li><Link to="/help" className="hover:opacity-60">Help & Contact</Link></li>
              <li><Link to="/shipping" className="hover:opacity-60">Shipping</Link></li>
              <li><Link to="/returns" className="hover:opacity-60">Returns</Link></li>
              <li><Link to="/size-guide" className="hover:opacity-60">Size Guide</Link></li>
              <li><Link to="/order-tracking" className="hover:opacity-60">Track Order</Link></li>
            </ul>
            <div className="flex items-center gap-4 mt-8">
              <a data-testid="social-instagram" href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:opacity-60" aria-label="Instagram"><Instagram size={18} /></a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="hover:opacity-60" aria-label="Twitter"><Twitter size={18} /></a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:opacity-60" aria-label="Youtube"><Youtube size={18} /></a>
            </div>
          </div>
        </div>

        <div className="mt-20 border-t border-bone/10 pt-8 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div className="eyebrow text-bone/50">© 2026 WEARHR · WEAR YOUR AMBITION · MUMBAI · MILAN · TOKYO</div>
          <div className="flex gap-6 eyebrow text-bone/50">
            <Link to="/privacy">PRIVACY</Link>
            <Link to="/terms">TERMS</Link>
            <Link to="/cookies">COOKIES</Link>
          </div>
        </div>

        <div className="mt-16 overflow-hidden select-none">
          <div className="font-display font-black leading-[0.85] tracking-tighter text-bone/95" style={{ fontSize: "clamp(6rem, 22vw, 26rem)" }}>
            WEARHR
          </div>
        </div>
      </div>
    </footer>
  );
}
