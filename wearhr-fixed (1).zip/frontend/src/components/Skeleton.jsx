import React from "react";

export function SkeletonCard() {
  return (
    <div className="animate-pulse">
      <div className="aspect-[4/5] bg-ink-2 shimmer" />
      <div className="mt-4 flex items-start justify-between gap-4">
        <div className="h-3 w-2/3 bg-ink-2 shimmer" />
        <div className="h-3 w-10 bg-ink-2 shimmer" />
      </div>
    </div>
  );
}

export function SkeletonGrid({ count = 8, cols = "grid-cols-2 md:grid-cols-3 lg:grid-cols-4" }) {
  return (
    <div className={`grid ${cols} gap-4 md:gap-8`}>
      {Array.from({ length: count }).map((_, i) => <SkeletonCard key={i} />)}
    </div>
  );
}
