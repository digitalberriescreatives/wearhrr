import React from "react";
import { motion } from "framer-motion";

// Split text into characters with staggered reveal.
export default function SplitText({ text, className = "", as = "span", delay = 0, italic = false }) {
  const As = as;
  const words = String(text).split(" ");
  return (
    <As className={className} aria-label={text}>
      {words.map((w, wi) => (
        <span key={wi} className="inline-block overflow-hidden align-top mr-[0.28em] last:mr-0">
          <motion.span
            initial={{ y: "110%" }}
            animate={{ y: 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: delay + wi * 0.06 }}
            className={`inline-block ${italic ? "italic font-normal" : ""}`}
          >
            {w}
          </motion.span>
        </span>
      ))}
    </As>
  );
}
