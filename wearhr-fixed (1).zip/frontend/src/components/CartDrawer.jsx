import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { X, Minus, Plus, Trash2 } from "lucide-react";
import { useApp } from "../context/AppContext";
import { formatINR } from "../lib/api";

export default function CartDrawer() {
  const { cart, cartOpen, setCartOpen, updateQty, removeItem } = useApp();
  const nav = useNavigate();
  const subtotal = cart.reduce((a, i) => a + i.price * i.qty, 0);
  return (
    <AnimatePresence>
      {cartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-ink-0/70 z-[80]"
            onClick={() => setCartOpen(false)}
          />
          <motion.aside
            data-testid="cart-drawer"
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="fixed top-0 right-0 bottom-0 z-[81] w-full sm:w-[460px] bg-ink-0 border-l border-bone/10 flex flex-col"
          >
            <div className="flex items-center justify-between px-6 py-5 border-b border-bone/10">
              <div className="eyebrow">YOUR BAG · {cart.length} {cart.length === 1 ? "ITEM" : "ITEMS"}</div>
              <button data-testid="cart-close" onClick={() => setCartOpen(false)} aria-label="Close cart"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center px-8 text-center">
                  <div className="font-display text-4xl italic mb-4">Empty vessel.</div>
                  <p className="font-body text-bone/60 mb-8">Nothing here yet. The archive awaits.</p>
                  <Link data-testid="cart-empty-shop" to="/shop" onClick={() => setCartOpen(false)} className="eyebrow underline underline-offset-8">EXPLORE THE COLLECTION →</Link>
                </div>
              ) : (
                <ul className="divide-y divide-bone/10">
                  {cart.map((it, idx) => (
                    <li key={idx} className="p-6 flex gap-4" data-testid={`cart-item-${idx}`}>
                      <img src={it.image} alt={it.title} className="w-24 h-32 object-cover bg-ink-1" />
                      <div className="flex-1 flex flex-col">
                        <Link to={`/product/${it.slug}`} onClick={() => setCartOpen(false)} className="font-body text-sm mb-1 hover:opacity-70">{it.title}</Link>
                        <div className="eyebrow text-bone/50 mb-3">SIZE {it.size}{it.color ? ` · ${it.color}` : ""}</div>
                        <div className="mt-auto flex items-center justify-between">
                          <div className="inline-flex items-center border border-bone/20">
                            <button data-testid={`qty-minus-${idx}`} onClick={() => updateQty(idx, it.qty - 1)} className="w-8 h-8 flex items-center justify-center hover:bg-bone hover:text-ink-0" aria-label="Decrease"><Minus size={12} /></button>
                            <span className="w-8 text-center font-mono text-sm">{it.qty}</span>
                            <button data-testid={`qty-plus-${idx}`} onClick={() => updateQty(idx, it.qty + 1)} className="w-8 h-8 flex items-center justify-center hover:bg-bone hover:text-ink-0" aria-label="Increase"><Plus size={12} /></button>
                          </div>
                          <div className="font-mono text-sm">{formatINR(it.price * it.qty)}</div>
                        </div>
                      </div>
                      <button data-testid={`cart-remove-${idx}`} onClick={() => removeItem(idx)} className="text-bone/50 hover:text-bone" aria-label="Remove"><Trash2 size={16} /></button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            {cart.length > 0 && (
              <div className="border-t border-bone/10 px-6 py-6 space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="eyebrow text-bone/60">SUBTOTAL</span>
                  <span className="font-mono">{formatINR(subtotal)}</span>
                </div>
                <p className="eyebrow text-bone/40">SHIPPING & TAX CALCULATED AT CHECKOUT</p>
                <button
                  data-testid="cart-checkout-btn"
                  onClick={() => { setCartOpen(false); nav("/checkout"); }}
                  className="w-full bg-bone text-ink-0 py-4 eyebrow hover:bg-bone/85"
                >
                  CHECKOUT — {formatINR(subtotal)}
                </button>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
