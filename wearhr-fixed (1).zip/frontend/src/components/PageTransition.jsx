import React from "react";
import { motion } from "framer-motion";

// Wraps every route so navigation feels like a cut between chapters
// rather than an abrupt swap — a soft veil-reveal in the brand's own
// monochrome palette, no gradients, no color.
export default function PageTransition({ children }) {
  return (
    <motion.div
      initial="hidden"
      animate="visible"
      exit="hidden"
      variants={{
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } },
      }}
    >
      <motion.div
        initial={{ clipPath: "inset(0 0 0 0)" }}
        className="relative"
      >
        {children}
      </motion.div>
      <motion.div
        aria-hidden
        className="fixed inset-0 z-[95] bg-ink-0 pointer-events-none origin-top"
        initial={{ scaleY: 1 }}
        animate={{ scaleY: 0 }}
        exit={{ scaleY: 1 }}
        transition={{ duration: 0.7, ease: [0.76, 0, 0.24, 1] }}
      />
    </motion.div>
  );
}
