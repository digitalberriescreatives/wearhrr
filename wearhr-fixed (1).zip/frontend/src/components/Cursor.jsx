import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

export default function Cursor() {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [hover, setHover] = useState(false);
  const raf = useRef();
  useEffect(() => {
    const onMove = (e) => {
      cancelAnimationFrame(raf.current);
      raf.current = requestAnimationFrame(() => setPos({ x: e.clientX, y: e.clientY }));
    };
    const onOver = (e) => {
      const el = e.target;
      const interactive = el.closest("a, button, [role='button'], input, textarea, [data-cursor='hover']");
      setHover(!!interactive);
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mouseover", onOver, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseover", onOver);
    };
  }, []);
  return (
    <>
      <motion.div
        aria-hidden
        className="pointer-events-none fixed z-[99] rounded-full mix-blend-difference"
        style={{ background: "#F5F5F0" }}
        animate={{ x: pos.x - (hover ? 24 : 4), y: pos.y - (hover ? 24 : 4), width: hover ? 48 : 8, height: hover ? 48 : 8 }}
        transition={{ type: "spring", stiffness: 500, damping: 40, mass: 0.4 }}
      />
    </>
  );
}
