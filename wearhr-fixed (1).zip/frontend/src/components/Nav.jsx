import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, Search, ShoppingBag, Heart, User, X } from "lucide-react";
import { useApp } from "../context/AppContext";

const links = [
  { to: "/shop", label: "SHOP" },
  { to: "/shop/tees", label: "TEES" },
  { to: "/shop/hoodies", label: "HOODIES" },
  { to: "/shop/jackets", label: "OUTERWEAR" },
  { to: "/shop/denim", label: "DENIM" },
  { to: "/shop/accessories", label: "ACCESSORIES" },
  { to: "/lookbook", label: "LOOKBOOK" },
  { to: "/story", label: "STORY" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { cart, wishlist, setCartOpen, user } = useApp();
  const loc = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => { setOpen(false); }, [loc.pathname]);

  const cartCount = cart.reduce((a, i) => a + i.qty, 0);

  return (
    <>
      <header
        data-testid="site-nav"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-luxe ${scrolled ? "bg-ink-0/85 backdrop-blur-2xl border-b border-bone/10" : "bg-transparent"}`}
      >
        <div className="max-w-[1800px] mx-auto px-6 md:px-10 lg:px-14">
          <div className="flex items-center justify-between h-16 md:h-20">
            <div className="flex items-center gap-4">
              <button data-testid="menu-toggle" onClick={() => setOpen(true)} className="lg:hidden" aria-label="Open menu">
                <Menu size={22} />
              </button>
              <Link data-testid="nav-shop-link-desktop" to="/shop" className="hidden lg:block font-sans text-xs tracking-widest2 uppercase nav-link-underline hover:opacity-90">Shop All</Link>
              <Link data-testid="nav-lookbook-link-desktop" to="/lookbook" className="hidden lg:block font-sans text-xs tracking-widest2 uppercase nav-link-underline hover:opacity-90">Lookbook</Link>
              <Link data-testid="nav-story-link-desktop" to="/story" className="hidden lg:block font-sans text-xs tracking-widest2 uppercase nav-link-underline hover:opacity-90">Story</Link>
            </div>
            <Link to="/" data-testid="nav-logo" className="font-display text-[1.5rem] md:text-[1.8rem] font-black tracking-tight leading-none transition-transform duration-500 ease-luxe hover:scale-[1.03] inline-block">WEARHR</Link>
            <div className="flex items-center gap-4 md:gap-5">
              <button data-testid="nav-search-btn" onClick={() => setSearchOpen(true)} aria-label="Search" className="transition-transform duration-300 hover:scale-110"><Search size={20} /></button>
              <Link data-testid="nav-wishlist-btn" to="/wishlist" aria-label="Wishlist" className="relative transition-transform duration-300 hover:scale-110">
                <Heart size={20} />
                {wishlist.length > 0 && <span className="absolute -top-2 -right-2 text-[10px] font-mono bg-bone text-ink-0 px-1 rounded-full">{wishlist.length}</span>}
              </Link>
              <Link data-testid="nav-account-btn" to={user ? "/account" : "/login"} aria-label="Account" className="transition-transform duration-300 hover:scale-110"><User size={20} /></Link>
              <button data-testid="nav-cart-btn" onClick={() => setCartOpen(true)} className="relative transition-transform duration-300 hover:scale-110" aria-label="Cart">
                <ShoppingBag size={20} />
                {cartCount > 0 && <span className="absolute -top-2 -right-2 text-[10px] font-mono bg-bone text-ink-0 px-1 rounded-full">{cartCount}</span>}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile / mega menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            data-testid="mobile-menu"
            initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-[60] bg-ink-0 flex flex-col"
          >
            <div className="flex items-center justify-between px-6 py-5 border-b border-bone/10">
              <span className="font-display text-2xl">WEARHR</span>
              <button data-testid="menu-close" onClick={() => setOpen(false)} aria-label="Close menu"><X size={22} /></button>
            </div>
            <nav className="flex-1 flex flex-col justify-center px-8 gap-6">
              {links.map((l, i) => (
                <motion.div key={l.to} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.05 * i + 0.1 }}>
                  <Link data-testid={`menu-link-${l.label.toLowerCase()}`} to={l.to} className="section-display block leading-tight hover:italic">
                    {l.label}
                  </Link>
                </motion.div>
              ))}
            </nav>
            <div className="px-8 py-6 border-t border-bone/10 eyebrow text-bone/50 flex justify-between">
              <span>MUMBAI · MILAN</span>
              <span>WEARHR.IN</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}

function SearchOverlay({ open, onClose }) {
  const [q, setQ] = useState("");
  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] bg-ink-0/95 backdrop-blur-xl flex flex-col">
          <div className="flex justify-between items-center px-6 py-5 border-b border-bone/10">
            <span className="eyebrow">SEARCH THE ARCHIVE</span>
            <button data-testid="search-close" onClick={onClose} aria-label="Close search"><X size={22} /></button>
          </div>
          <div className="flex-1 flex flex-col justify-center px-6 md:px-24">
            <form onSubmit={(e) => { e.preventDefault(); if (q) window.location.href = `/shop?q=${encodeURIComponent(q)}`; }}>
              <input
                data-testid="search-input"
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search products, categories, drops..."
                className="w-full bg-transparent border-b border-bone/30 pb-4 text-3xl md:text-6xl font-display italic focus:outline-none focus:border-bone"
              />
            </form>
            <div className="mt-8 eyebrow text-bone/50">TRY: HEAVYWEIGHT · CARGO · SELVEDGE · OVERSHIRT</div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
