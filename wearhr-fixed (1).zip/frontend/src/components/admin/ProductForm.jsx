import React, { useEffect, useState } from "react";
import { X } from "lucide-react";
import { api } from "../../lib/api";

const CATEGORIES = ["tees", "hoodies", "sweatshirts", "jackets", "cargos", "joggers", "denim", "caps", "accessories"];

const EMPTY = {
  title: "",
  category: "tees",
  price: "",
  compare_at_price: "",
  description: "",
  materials: "",
  fit: "",
  care: "",
  sizes: "S, M, L, XL",
  colors: "",
  images: "",
  tags: "",
  stock: 100,
  featured: false,
  new_drop: false,
  best_seller: false,
};

function toFormState(product) {
  if (!product) return EMPTY;
  return {
    title: product.title || "",
    category: product.category || "tees",
    price: product.price ?? "",
    compare_at_price: product.compare_at_price ?? "",
    description: product.description || "",
    materials: (product.materials || []).join(", "),
    fit: product.fit || "",
    care: product.care || "",
    sizes: (product.sizes || []).join(", "),
    colors: (product.colors || []).join(", "),
    images: (product.images || []).join("\n"),
    tags: (product.tags || []).join(", "),
    stock: product.stock ?? 100,
    featured: !!product.featured,
    new_drop: !!product.new_drop,
    best_seller: !!product.best_seller,
  };
}

function splitList(str) {
  return String(str || "")
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

const input = "w-full bg-transparent border border-bone/20 px-4 py-3 focus:outline-none focus:border-bone placeholder:text-bone/40";
const label = "eyebrow text-bone/50 mb-2 block";

export default function ProductForm({ product, onClose, onSaved }) {
  const [form, setForm] = useState(() => toFormState(product));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const isEdit = !!product;

  useEffect(() => { setForm(toFormState(product)); }, [product]);

  const set = (k) => (e) => {
    const v = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [k]: v }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      const payload = {
        title: form.title.trim(),
        category: form.category,
        price: Math.round(Number(form.price)),
        compare_at_price: form.compare_at_price ? Math.round(Number(form.compare_at_price)) : null,
        description: form.description.trim(),
        materials: splitList(form.materials),
        fit: form.fit.trim() || null,
        care: form.care.trim() || null,
        sizes: splitList(form.sizes),
        colors: splitList(form.colors),
        images: splitList(form.images),
        tags: splitList(form.tags),
        stock: Math.round(Number(form.stock) || 0),
        featured: form.featured,
        new_drop: form.new_drop,
        best_seller: form.best_seller,
      };
      if (!payload.title) throw new Error("Title is required.");
      if (!payload.price || payload.price <= 0) throw new Error("Enter a valid price.");
      if (payload.images.length === 0) throw new Error("Add at least one image URL.");

      if (isEdit) {
        await api.put(`/admin/products/${product.id}`, payload);
      } else {
        await api.post("/admin/products", payload);
      }
      onSaved();
    } catch (e) {
      setErr(e.response?.data?.detail || e.message || "Could not save product.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[90] bg-ink-0/80 backdrop-blur-sm flex items-start md:items-center justify-center p-4 md:p-8 overflow-y-auto">
      <div className="bg-ink-0 border border-bone/15 w-full max-w-2xl my-8">
        <div className="flex items-center justify-between px-6 md:px-8 py-5 border-b border-bone/10">
          <h2 className="font-display text-2xl md:text-3xl italic">{isEdit ? "Edit piece." : "New piece."}</h2>
          <button data-testid="product-form-close" onClick={onClose} aria-label="Close"><X size={22} /></button>
        </div>
        <form onSubmit={submit} className="px-6 md:px-8 py-8 space-y-6">
          <div>
            <label className={label}>TITLE</label>
            <input data-testid="pf-title" required value={form.title} onChange={set("title")} placeholder="Monolith Oversized Tee — Obsidian" className={input} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={label}>CATEGORY</label>
              <select data-testid="pf-category" value={form.category} onChange={set("category")} className={input}>
                {CATEGORIES.map((c) => <option key={c} value={c} className="bg-ink-0">{c}</option>)}
              </select>
            </div>
            <div>
              <label className={label}>STOCK</label>
              <input data-testid="pf-stock" type="number" min="0" value={form.stock} onChange={set("stock")} className={input} />
            </div>
            <div>
              <label className={label}>PRICE (₹)</label>
              <input data-testid="pf-price" required type="number" min="1" value={form.price} onChange={set("price")} placeholder="3499" className={input} />
            </div>
            <div>
              <label className={label}>COMPARE-AT PRICE (₹, optional)</label>
              <input data-testid="pf-compare-price" type="number" min="0" value={form.compare_at_price} onChange={set("compare_at_price")} placeholder="4999" className={input} />
            </div>
          </div>

          <div>
            <label className={label}>DESCRIPTION</label>
            <textarea data-testid="pf-description" required rows={3} value={form.description} onChange={set("description")} placeholder="Heavyweight 320 GSM cotton..." className={input} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={label}>SIZES (comma separated)</label>
              <input data-testid="pf-sizes" value={form.sizes} onChange={set("sizes")} placeholder="S, M, L, XL" className={input} />
            </div>
            <div>
              <label className={label}>COLORS (comma separated)</label>
              <input data-testid="pf-colors" value={form.colors} onChange={set("colors")} placeholder="Obsidian, Bone" className={input} />
            </div>
            <div>
              <label className={label}>MATERIALS (comma separated)</label>
              <input data-testid="pf-materials" value={form.materials} onChange={set("materials")} placeholder="320 GSM combed cotton" className={input} />
            </div>
            <div>
              <label className={label}>TAGS (comma separated)</label>
              <input data-testid="pf-tags" value={form.tags} onChange={set("tags")} placeholder="oversized, heavyweight" className={input} />
            </div>
            <div>
              <label className={label}>FIT</label>
              <input data-testid="pf-fit" value={form.fit} onChange={set("fit")} placeholder="Oversized fit." className={input} />
            </div>
            <div>
              <label className={label}>CARE</label>
              <input data-testid="pf-care" value={form.care} onChange={set("care")} placeholder="Cold wash inside out." className={input} />
            </div>
          </div>

          <div>
            <label className={label}>IMAGE URLS (one per line)</label>
            <textarea data-testid="pf-images" required rows={3} value={form.images} onChange={set("images")} placeholder="https://...jpg" className={input} />
          </div>

          <div className="flex flex-wrap gap-6">
            <label className="flex items-center gap-2 eyebrow cursor-pointer">
              <input data-testid="pf-featured" type="checkbox" checked={form.featured} onChange={set("featured")} /> FEATURED
            </label>
            <label className="flex items-center gap-2 eyebrow cursor-pointer">
              <input data-testid="pf-newdrop" type="checkbox" checked={form.new_drop} onChange={set("new_drop")} /> NEW DROP
            </label>
            <label className="flex items-center gap-2 eyebrow cursor-pointer">
              <input data-testid="pf-bestseller" type="checkbox" checked={form.best_seller} onChange={set("best_seller")} /> BEST SELLER
            </label>
          </div>

          {err && <p data-testid="pf-error" className="text-red-400 eyebrow text-xs">{err}</p>}

          <div className="flex gap-3 pt-2">
            <button data-testid="pf-submit" type="submit" disabled={busy} className="flex-1 bg-bone text-ink-0 py-4 eyebrow hover:bg-bone/85 disabled:opacity-50">
              {busy ? "SAVING…" : isEdit ? "SAVE CHANGES" : "CREATE PRODUCT"}
            </button>
            <button type="button" onClick={onClose} className="px-6 border border-bone/25 eyebrow hover:border-bone">CANCEL</button>
          </div>
        </form>
      </div>
    </div>
  );
}
