import React from "react";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    // Surface it in the console so it's debuggable, but never let it
    // take down the whole page with no explanation.
    // eslint-disable-next-line no-console
    console.error("WEARHR runtime error:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-ink-0 text-bone px-6 text-center">
          <div className="eyebrow text-bone/50 mb-6">— SOMETHING SNAGGED</div>
          <h1 className="font-display text-4xl md:text-6xl mb-6">We hit a thread.</h1>
          <p className="font-body text-bone/60 max-w-md mb-10">
            This page ran into an unexpected error. Reloading usually fixes it.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="eyebrow bg-bone text-ink-0 px-8 py-4 hover:bg-bone/85"
          >
            RELOAD THE PAGE
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
