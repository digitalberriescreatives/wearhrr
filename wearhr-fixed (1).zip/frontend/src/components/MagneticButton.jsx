import React, { useRef } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function MagneticButton({ children, className = "", onClick, testid, as: As = "button", href, ariaLabel }) {
  const ref = useRef(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 300, damping: 25 });
  const sy = useSpring(y, { stiffness: 300, damping: 25 });

  const onMove = (e) => {
    const r = ref.current.getBoundingClientRect();
    const mx = e.clientX - r.left - r.width / 2;
    const my = e.clientY - r.top - r.height / 2;
    x.set(mx * 0.25);
    y.set(my * 0.35);
  };
  const onLeave = () => { x.set(0); y.set(0); };

  const props = {
    ref,
    onMouseMove: onMove,
    onMouseLeave: onLeave,
    onClick,
    "data-testid": testid,
    "aria-label": ariaLabel,
    className: `relative inline-flex items-center justify-center transition-colors ${className}`,
  };
  if (As === "a") props.href = href;

  return (
    <motion.div style={{ x: sx, y: sy }} className="inline-block">
      <As {...props}>{children}</As>
    </motion.div>
  );
}
