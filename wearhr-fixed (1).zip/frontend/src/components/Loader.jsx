import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Loader() {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);
  useEffect(() => {
    let n = 0;
    const t = setInterval(() => {
      n += Math.random() * 14 + 4;
      if (n >= 100) { n = 100; clearInterval(t); setTimeout(() => setDone(true), 500); }
      setProgress(Math.floor(n));
    }, 90);
    return () => clearInterval(t);
  }, []);
  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          data-testid="cinematic-loader"
          className="fixed inset-0 z-[100] bg-ink-0 flex flex-col items-center justify-between py-12 md:py-16 px-8"
          initial={{ opacity: 1 }}
          exit={{ y: "-100%" }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
        >
          <div className="w-full flex items-center justify-between eyebrow text-bone/60">
            <span>WEARHR — EST. 2026</span>
            <span>MUMBAI · MILAN · TOKYO</span>
          </div>
          <div className="flex-1 w-full flex items-center justify-center">
            <div className="text-bone hero-display leading-none tracking-tighter">
              <span className="block">WEAR</span>
              <span className="block italic font-normal">your ambition.</span>
            </div>
          </div>
          <div className="w-full flex items-end justify-between">
            <span className="eyebrow text-bone/70">LOADING · A NEW STANDARD</span>
            <span className="font-mono text-bone tabular-nums text-4xl md:text-6xl">{progress.toString().padStart(3, "0")}</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
