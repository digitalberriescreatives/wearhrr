import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Heart } from "lucide-react";
import { useApp } from "../context/AppContext";
import { formatINR } from "../lib/api";

export default function ProductCard({ product, index = 0 }) {
  const { wishlist, toggleWishlist } = useApp();
  const inWishlist = wishlist.some((p) => p.id === product.id);
  return (
    <motion.article
      data-testid={`product-card-${product.slug}`}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: (index % 6) * 0.06 }}
      className="group relative"
    >
      <Link data-testid={`product-link-${product.slug}`} to={`/product/${product.slug}`} className="block">
        <div className="relative overflow-hidden bg-ink-1 aspect-[4/5]">
          <motion.img
            src={product.images?.[0]}
            alt={product.title}
            loading="lazy"
            className="w-full h-full object-cover"
            initial={{ scale: 1.05 }}
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          />
          {product.images?.[1] && (
            <img
              src={product.images[1]}
              alt=""
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-700"
            />
          )}
          {product.new_drop && <span className="absolute top-4 left-4 eyebrow bg-bone text-ink-0 px-2 py-1">NEW DROP</span>}
          {product.best_seller && !product.new_drop && <span className="absolute top-4 left-4 eyebrow bg-ink-0 text-bone px-2 py-1 border border-bone/20">BEST SELLER</span>}
          <button
            data-testid={`wishlist-toggle-${product.slug}`}
            onClick={(e) => { e.preventDefault(); toggleWishlist(product); }}
            className="absolute top-4 right-4 w-9 h-9 flex items-center justify-center border border-bone/30 hover:bg-bone hover:text-ink-0 transition-colors"
            aria-label="Toggle wishlist"
          >
            <Heart size={16} fill={inWishlist ? "#F5F5F0" : "transparent"} />
          </button>
        </div>
        <div className="mt-4 flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="eyebrow text-bone/50 mb-1">{product.category?.toUpperCase()}</div>
            <h3 className="font-body text-[15px] md:text-base truncate">{product.title}</h3>
          </div>
          <div className="text-right whitespace-nowrap">
            <div className="font-mono text-sm">{formatINR(product.price)}</div>
            {product.compare_at_price && (
              <div className="font-mono text-[11px] text-bone/40 line-through">{formatINR(product.compare_at_price)}</div>
            )}
          </div>
        </div>
      </Link>
    </motion.article>
  );
}
