import React, { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { AppProvider } from "./context/AppContext";
import Loader from "./components/Loader";
import Cursor from "./components/Cursor";
import Nav from "./components/Nav";
import Footer from "./components/Footer";
import CartDrawer from "./components/CartDrawer";
import PageTransition from "./components/PageTransition";
import ScrollProgress from "./components/ScrollProgress";
import useLenis from "./hooks/useLenis";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Checkout from "./pages/Checkout";
import Wishlist from "./pages/Wishlist";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Account from "./pages/Account";
import Lookbook from "./pages/Lookbook";
import Story from "./pages/Story";
import OrderTracking from "./pages/OrderTracking";
import Admin from "./pages/Admin";
import InfoPage from "./pages/InfoPage";
import NotFound from "./pages/NotFound";

function AppRoutes() {
  const loc = useLocation();
  const hideChrome = ["/login", "/register"].includes(loc.pathname);
  useLenis();

  return (
    <>
      <ScrollProgress />
      {!hideChrome && <Nav />}
      <main>
        <AnimatePresence mode="wait" initial={false}>
          <Routes location={loc} key={loc.pathname}>
            <Route path="/" element={<PageTransition><Home /></PageTransition>} />
            <Route path="/shop" element={<PageTransition><Shop /></PageTransition>} />
            <Route path="/shop/:category" element={<PageTransition><Shop /></PageTransition>} />
            <Route path="/product/:slug" element={<PageTransition><ProductDetail /></PageTransition>} />
            <Route path="/wishlist" element={<PageTransition><Wishlist /></PageTransition>} />
            <Route path="/checkout" element={<PageTransition><Checkout /></PageTransition>} />
            <Route path="/lookbook" element={<PageTransition><Lookbook /></PageTransition>} />
            <Route path="/story" element={<PageTransition><Story /></PageTransition>} />
            <Route path="/login" element={<PageTransition><Login /></PageTransition>} />
            <Route path="/register" element={<PageTransition><Register /></PageTransition>} />
            <Route path="/account" element={<PageTransition><Account /></PageTransition>} />
            <Route path="/order-tracking" element={<PageTransition><OrderTracking /></PageTransition>} />
            <Route path="/admin" element={<PageTransition><Admin /></PageTransition>} />
            <Route path="/privacy" element={<PageTransition><InfoPage slug="privacy" /></PageTransition>} />
            <Route path="/terms" element={<PageTransition><InfoPage slug="terms" /></PageTransition>} />
            <Route path="/cookies" element={<PageTransition><InfoPage slug="cookies" /></PageTransition>} />
            <Route path="/shipping" element={<PageTransition><InfoPage slug="shipping" /></PageTransition>} />
            <Route path="/returns" element={<PageTransition><InfoPage slug="returns" /></PageTransition>} />
            <Route path="/size-guide" element={<PageTransition><InfoPage slug="size-guide" /></PageTransition>} />
            <Route path="/help" element={<PageTransition><InfoPage slug="help" /></PageTransition>} />
            <Route path="/careers" element={<PageTransition><InfoPage slug="careers" /></PageTransition>} />
            <Route path="/press" element={<PageTransition><InfoPage slug="press" /></PageTransition>} />
            <Route path="/sustainability" element={<PageTransition><InfoPage slug="sustainability" /></PageTransition>} />
            <Route path="*" element={<PageTransition><NotFound /></PageTransition>} />
          </Routes>
        </AnimatePresence>
      </main>
      {!hideChrome && <Footer />}
      <CartDrawer />
    </>
  );
}

export default function App() {
  useEffect(() => {
    // Hand off from the static HTML splash to the cinematic React loader
    // the instant the app tree has actually mounted.
    const splash = document.getElementById("initial-splash");
    if (splash) splash.remove();
  }, []);

  return (
    <AppProvider>
      <Loader />
      <Cursor />
      <AppRoutes />
    </AppProvider>
  );
}
