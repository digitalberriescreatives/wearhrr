// Minimal static file server for the production build, with SPA fallback
// so that refreshing on a deep link (e.g. /product/some-item) serves
// index.html instead of a raw 404. Use this if you're self-hosting
// (Render, Railway, a VPS, etc.) rather than Netlify/Vercel, which have
// their own config files (_redirects / vercel.json) already included.
//
// Usage:
//   npm run build
//   node serve.js
//
// Requires: npm install express (not added to package.json by default
// to keep the frontend a pure static build — install it only if you use
// this script).

const path = require("path");
const express = require("express");

const app = express();
const buildDir = path.join(__dirname, "build");
const port = process.env.PORT || 3000;

app.use(express.static(buildDir));

app.get("*", (req, res) => {
  res.sendFile(path.join(buildDir, "index.html"));
});

app.listen(port, () => {
  console.log(`WEARHR frontend serving on port ${port}`);
});
