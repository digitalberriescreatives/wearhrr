"""
WEARHR backend regression tests.
Covers: health, products, categories, auth (register/login/me),
wishlist, reviews, newsletter, orders (COD + Razorpay), verify, admin RBAC.
"""
import os
import uuid
import time
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
# Fall back to reading frontend/.env if not exported
if not BASE_URL:
    try:
        with open("/app/frontend/.env") as f:
            for line in f:
                if line.startswith("REACT_APP_BACKEND_URL="):
                    BASE_URL = line.split("=", 1)[1].strip().rstrip("/")
                    break
    except Exception:
        pass

ADMIN_EMAIL = "admin@wearhr.in"
ADMIN_PASSWORD = "Wearhr@2026"


# --------------------- Fixtures ---------------------
@pytest.fixture(scope="session")
def api():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session")
def admin_token(api):
    r = api.post(f"{BASE_URL}/api/auth/login", json={
        "email": ADMIN_EMAIL, "password": ADMIN_PASSWORD
    })
    assert r.status_code == 200, f"admin login failed: {r.status_code} {r.text}"
    data = r.json()
    return data["token"]


@pytest.fixture(scope="session")
def customer_creds():
    email = f"TEST_user_{uuid.uuid4().hex[:8]}@wearhr.in"
    return {"email": email, "password": "TestPass123", "name": "Test User"}


@pytest.fixture(scope="session")
def customer_token(api, customer_creds):
    r = api.post(f"{BASE_URL}/api/auth/register", json=customer_creds)
    assert r.status_code == 200, f"register failed: {r.status_code} {r.text}"
    return r.json()["token"]


@pytest.fixture(scope="session")
def first_product(api):
    r = api.get(f"{BASE_URL}/api/products", params={"limit": 1})
    assert r.status_code == 200
    items = r.json()["items"]
    assert len(items) > 0, "No products seeded"
    return items[0]


# --------------------- Health ---------------------
class TestHealth:
    def test_health(self, api):
        r = api.get(f"{BASE_URL}/api/health")
        assert r.status_code == 200
        data = r.json()
        assert data.get("ok") is True
        assert data.get("service") == "wearhr"


# --------------------- Products ---------------------
class TestProducts:
    def test_list_returns_at_least_45(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"limit": 100})
        assert r.status_code == 200
        data = r.json()
        assert "items" in data and "total" in data
        assert data["total"] >= 45, f"Expected >=45 products, got {data['total']}"
        assert len(data["items"]) >= 45

    def test_filter_featured(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"featured": "true", "limit": 50})
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) > 0
        for it in items:
            assert it["featured"] is True

    def test_filter_new_drop(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"new_drop": "true"})
        assert r.status_code == 200
        for it in r.json()["items"]:
            assert it["new_drop"] is True

    def test_filter_best_seller(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"best_seller": "true"})
        assert r.status_code == 200
        for it in r.json()["items"]:
            assert it["best_seller"] is True

    def test_search_q(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"q": "hoodie"})
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) > 0
        # Ensure result contains hoodie in title/category/tags
        joined = " ".join([f"{i['title']} {i['category']} {' '.join(i.get('tags',[]))}" for i in items]).lower()
        assert "hoodie" in joined

    def test_sort_price_asc(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"sort": "price_asc", "limit": 10})
        assert r.status_code == 200
        prices = [i["price"] for i in r.json()["items"]]
        assert prices == sorted(prices)

    def test_sort_price_desc(self, api):
        r = api.get(f"{BASE_URL}/api/products", params={"sort": "price_desc", "limit": 10})
        assert r.status_code == 200
        prices = [i["price"] for i in r.json()["items"]]
        assert prices == sorted(prices, reverse=True)

    def test_pagination_skip(self, api):
        # Use stable sort (price_asc) since default 'featured' has same created_at ties.
        r1 = api.get(f"{BASE_URL}/api/products", params={"limit": 5, "skip": 0, "sort": "price_asc"})
        r2 = api.get(f"{BASE_URL}/api/products", params={"limit": 5, "skip": 5, "sort": "price_asc"})
        assert r1.status_code == 200 and r2.status_code == 200
        ids1 = [i["id"] for i in r1.json()["items"]]
        ids2 = [i["id"] for i in r2.json()["items"]]
        assert len(ids1) == 5 and len(ids2) == 5
        assert set(ids1).isdisjoint(set(ids2)), "skip pagination returned overlapping items"

    def test_get_product_by_slug(self, api, first_product):
        slug = first_product["slug"]
        r = api.get(f"{BASE_URL}/api/products/{slug}")
        assert r.status_code == 200
        data = r.json()
        assert "product" in data and "related" in data
        assert data["product"]["slug"] == slug
        # related should be from same category (or empty if only 1)
        for rel in data["related"]:
            assert rel["category"] == data["product"]["category"]
            assert rel["id"] != data["product"]["id"]

    def test_get_product_404(self, api):
        r = api.get(f"{BASE_URL}/api/products/does-not-exist-xyz")
        assert r.status_code == 404

    def test_review_request_slug_elite_fashion_44(self, api):
        """Review request references /api/products/elite-fashion-44 — verify handling."""
        r = api.get(f"{BASE_URL}/api/products/elite-fashion-44")
        # Either exists (200) or gracefully 404
        assert r.status_code in (200, 404)


# --------------------- Categories ---------------------
class TestCategories:
    def test_categories(self, api):
        r = api.get(f"{BASE_URL}/api/categories")
        assert r.status_code == 200
        cats = r.json()["items"]
        assert isinstance(cats, list) and len(cats) > 0
        assert "tees" in cats or "hoodies" in cats


# --------------------- Auth ---------------------
class TestAuth:
    def test_register_new_user(self, api):
        email = f"TEST_reg_{uuid.uuid4().hex[:8]}@wearhr.in"
        r = api.post(f"{BASE_URL}/api/auth/register", json={
            "email": email, "password": "TestPass123", "name": "Reg User"
        })
        assert r.status_code == 200
        data = r.json()
        assert "token" in data and isinstance(data["token"], str) and len(data["token"]) > 20
        # Backend normalizes email to lowercase
        assert data["user"]["email"] == email.lower()
        assert data["user"]["role"] == "customer"

    def test_register_duplicate(self, api, customer_creds, customer_token):
        r = api.post(f"{BASE_URL}/api/auth/register", json=customer_creds)
        assert r.status_code == 400

    def test_login_admin(self, api):
        r = api.post(f"{BASE_URL}/api/auth/login", json={
            "email": ADMIN_EMAIL, "password": ADMIN_PASSWORD
        })
        assert r.status_code == 200
        data = r.json()
        assert data["user"]["role"] == "admin"
        assert data["user"]["email"] == ADMIN_EMAIL

    def test_login_invalid(self, api):
        r = api.post(f"{BASE_URL}/api/auth/login", json={
            "email": ADMIN_EMAIL, "password": "wrongpass"
        })
        assert r.status_code == 401

    def test_me_admin(self, api, admin_token):
        r = api.get(f"{BASE_URL}/api/auth/me", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert r.json()["role"] == "admin"

    def test_me_no_token(self, api):
        r = api.get(f"{BASE_URL}/api/auth/me")
        assert r.status_code == 401


# --------------------- Newsletter ---------------------
class TestNewsletter:
    def test_subscribe(self, api):
        r = api.post(f"{BASE_URL}/api/newsletter", json={"email": f"TEST_news_{uuid.uuid4().hex[:6]}@wearhr.in"})
        assert r.status_code == 200
        assert r.json().get("ok") is True

    def test_subscribe_invalid_email(self, api):
        r = api.post(f"{BASE_URL}/api/newsletter", json={"email": "not-an-email"})
        assert r.status_code == 422


# --------------------- Wishlist ---------------------
class TestWishlist:
    def test_wishlist_flow(self, api, customer_token, first_product):
        headers = {"Authorization": f"Bearer {customer_token}"}
        pid = first_product["id"]
        # Add
        r = api.post(f"{BASE_URL}/api/wishlist", json={"product_id": pid}, headers=headers)
        assert r.status_code == 200
        # Get
        r = api.get(f"{BASE_URL}/api/wishlist", headers=headers)
        assert r.status_code == 200
        ids = [i["product_id"] for i in r.json()["items"]]
        assert pid in ids
        # Delete
        r = api.delete(f"{BASE_URL}/api/wishlist/{pid}", headers=headers)
        assert r.status_code == 200
        r = api.get(f"{BASE_URL}/api/wishlist", headers=headers)
        assert pid not in [i["product_id"] for i in r.json()["items"]]

    def test_wishlist_requires_auth(self, api):
        r = api.get(f"{BASE_URL}/api/wishlist")
        assert r.status_code == 401


# --------------------- Reviews ---------------------
class TestReviews:
    def test_add_and_list_review(self, api, customer_token, first_product):
        headers = {"Authorization": f"Bearer {customer_token}"}
        pid = first_product["id"]
        r = api.post(f"{BASE_URL}/api/reviews", json={
            "product_id": pid, "rating": 5, "title": "TEST", "body": "Great product"
        }, headers=headers)
        assert r.status_code == 200
        assert "id" in r.json()

        r = api.get(f"{BASE_URL}/api/reviews/{pid}")
        assert r.status_code == 200
        items = r.json()["items"]
        assert any(it.get("title") == "TEST" for it in items)

    def test_review_requires_auth(self, api, first_product):
        r = api.post(f"{BASE_URL}/api/reviews", json={
            "product_id": first_product["id"], "rating": 5, "body": "no auth"
        })
        assert r.status_code == 401

    def test_review_invalid_rating(self, api, customer_token, first_product):
        headers = {"Authorization": f"Bearer {customer_token}"}
        r = api.post(f"{BASE_URL}/api/reviews", json={
            "product_id": first_product["id"], "rating": 9, "body": "bad"
        }, headers=headers)
        assert r.status_code == 422


# --------------------- Orders ---------------------
def _address():
    return {
        "full_name": "Test Buyer",
        "phone": "9999999999",
        "email": "TEST_buyer@wearhr.in",
        "line1": "1 Test Lane",
        "line2": "Apt 1",
        "city": "Mumbai",
        "state": "MH",
        "postal_code": "400001",
        "country": "India",
    }


class TestOrders:
    def test_create_cod_order(self, api, first_product):
        payload = {
            "items": [{"product_id": first_product["id"], "size": "M", "color": "Bone", "qty": 1}],
            "address": _address(),
            "method": "cod",
        }
        r = api.post(f"{BASE_URL}/api/orders", json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        order = data["order"]
        assert order["method"] == "cod"
        assert order["status"] == "created"
        assert order["payment_status"] == "pending"
        assert "razorpay_order_id" not in order
        assert data.get("razorpay_key_id") is None
        assert order["subtotal"] == first_product["price"]
        # GET order back
        gid = order["id"]
        gr = api.get(f"{BASE_URL}/api/orders/{gid}")
        assert gr.status_code == 200
        assert gr.json()["order"]["id"] == gid

    def test_create_razorpay_order(self, api, first_product):
        """Only verify razorpay_order_id is set. DO NOT complete payment."""
        payload = {
            "items": [{"product_id": first_product["id"], "size": "M", "color": "Bone", "qty": 1}],
            "address": _address(),
            "method": "razorpay",
        }
        r = api.post(f"{BASE_URL}/api/orders", json=payload)
        # razorpay might not be reachable in preview env — accept 502 gracefully
        if r.status_code == 502:
            pytest.skip(f"Razorpay gateway unreachable: {r.text}")
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["order"]["method"] == "razorpay"
        assert data["order"].get("razorpay_order_id"), "razorpay_order_id must be set"
        assert data.get("razorpay_key_id"), "razorpay_key_id must be returned"

    def test_verify_invalid_signature(self, api, first_product):
        # First create a COD order to get an id
        payload = {
            "items": [{"product_id": first_product["id"], "size": "M", "qty": 1}],
            "address": _address(),
            "method": "cod",
        }
        r = api.post(f"{BASE_URL}/api/orders", json=payload)
        assert r.status_code == 200
        oid = r.json()["order"]["id"]
        # Attempt verify with junk signature
        v = api.post(f"{BASE_URL}/api/orders/verify", json={
            "order_id": oid,
            "razorpay_order_id": "order_bad",
            "razorpay_payment_id": "pay_bad",
            "razorpay_signature": "bad_signature_hex",
        })
        assert v.status_code == 400

    def test_get_order_404(self, api):
        # 24-hex non-existent id
        r = api.get(f"{BASE_URL}/api/orders/507f1f77bcf86cd799439011")
        assert r.status_code == 404

    def test_get_order_invalid_id(self, api):
        r = api.get(f"{BASE_URL}/api/orders/not-an-oid")
        assert r.status_code == 400


# --------------------- Admin RBAC ---------------------
class TestAdmin:
    def test_admin_stats_ok(self, api, admin_token):
        r = api.get(f"{BASE_URL}/api/admin/stats", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        data = r.json()
        for k in ("orders", "paid", "products", "users", "revenue"):
            assert k in data

    def test_admin_orders_ok(self, api, admin_token):
        r = api.get(f"{BASE_URL}/api/admin/orders", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        assert "items" in r.json()

    def test_admin_stats_forbidden_for_customer(self, api, customer_token):
        r = api.get(f"{BASE_URL}/api/admin/stats", headers={"Authorization": f"Bearer {customer_token}"})
        assert r.status_code == 403

    def test_admin_orders_forbidden_for_customer(self, api, customer_token):
        r = api.get(f"{BASE_URL}/api/admin/orders", headers={"Authorization": f"Bearer {customer_token}"})
        assert r.status_code == 403

    def test_admin_stats_requires_auth(self, api):
        r = api.get(f"{BASE_URL}/api/admin/stats")
        assert r.status_code == 401
