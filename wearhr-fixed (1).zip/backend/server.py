from dotenv import load_dotenv
load_dotenv()

import os
import re
import bcrypt
import jwt as pyjwt
import razorpay
import hmac
import hashlib
import secrets
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Any
from bson import ObjectId
from slugify import slugify

from fastapi import FastAPI, HTTPException, Depends, Request, Response, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr, Field
from motor.motor_asyncio import AsyncIOMotorClient

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("wearhr")

# ---------------------------------------------------------------
# Environment — never hard-crash the whole process over a missing
# var. A missing MONGO_URL/JWT_SECRET/Razorpay key should degrade
# the relevant feature, not take down every page on the site.
# ---------------------------------------------------------------
MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.environ.get("DB_NAME", "wearhr")
JWT_SECRET = os.environ.get("JWT_SECRET") or secrets.token_hex(32)
JWT_ALGO = "HS256"
RAZORPAY_KEY_ID = os.environ.get("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.environ.get("RAZORPAY_KEY_SECRET", "")

_missing = [k for k, v in {
    "MONGO_URL": os.environ.get("MONGO_URL"),
    "DB_NAME": os.environ.get("DB_NAME"),
    "JWT_SECRET": os.environ.get("JWT_SECRET"),
    "RAZORPAY_KEY_ID": os.environ.get("RAZORPAY_KEY_ID"),
    "RAZORPAY_KEY_SECRET": os.environ.get("RAZORPAY_KEY_SECRET"),
}.items() if not v]
if _missing:
    log.warning(
        "Missing env vars %s — using safe fallbacks. Set these in your .env "
        "for production (see backend/.env.example). Payments will not work "
        "until real Razorpay keys are set, and auth tokens will invalidate "
        "on every restart until JWT_SECRET is fixed.",
        _missing,
    )

client = AsyncIOMotorClient(MONGO_URL, serverSelectionTimeoutMS=8000)
db = client[DB_NAME]

try:
    rzp = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
except Exception:
    rzp = None
    log.warning("Razorpay client could not be initialized — check RAZORPAY_KEY_ID/SECRET.")

app = FastAPI(title="WEARHR API", version="1.0.0")

@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Any uncaught error becomes a clean JSON 500 instead of a dropped
    # connection / crashed worker — the frontend can always show a
    # friendly message instead of hanging forever.
    log.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(status_code=500, content={"detail": "Something went wrong. Please try again."})

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,  # using bearer tokens instead of cookies for simplicity here
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# Utilities
# -----------------------------
def now_utc() -> datetime:
    return datetime.now(timezone.utc)

def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False

def create_access_token(user_id: str, email: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "exp": now_utc() + timedelta(days=7),
        "type": "access",
    }
    return pyjwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

def serialize_doc(doc: dict) -> dict:
    if not doc:
        return doc
    out = {}
    for k, v in doc.items():
        if k == "_id":
            out["id"] = str(v)
        elif isinstance(v, ObjectId):
            out[k] = str(v)
        elif isinstance(v, datetime):
            out[k] = v.isoformat()
        else:
            out[k] = v
    return out

async def get_current_user(request: Request) -> dict:
    auth = request.headers.get("Authorization", "")
    token = None
    if auth.startswith("Bearer "):
        token = auth[7:]
    if not token:
        token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = pyjwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
    except pyjwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except pyjwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return serialize_doc({**user, "password_hash": None})

async def require_admin(user: dict = Depends(get_current_user)) -> dict:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    return user

async def optional_user(request: Request) -> Optional[dict]:
    try:
        return await get_current_user(request)
    except HTTPException:
        return None

# -----------------------------
# Schemas
# -----------------------------
class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6)
    name: Optional[str] = None

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class ProductIn(BaseModel):
    title: str
    category: str
    price: int
    compare_at_price: Optional[int] = None
    description: str
    materials: List[str] = []
    fit: Optional[str] = None
    care: Optional[str] = None
    sizes: List[str] = []
    colors: List[str] = []
    images: List[str] = []
    tags: List[str] = []
    stock: int = 100
    featured: bool = False
    new_drop: bool = False
    best_seller: bool = False

class CartItemIn(BaseModel):
    product_id: str
    size: str
    color: Optional[str] = None
    qty: int = 1

class WishlistIn(BaseModel):
    product_id: str

class NewsletterIn(BaseModel):
    email: EmailStr

class ReviewIn(BaseModel):
    product_id: str
    rating: int = Field(ge=1, le=5)
    title: Optional[str] = None
    body: str

class AddressIn(BaseModel):
    full_name: str
    phone: str
    email: EmailStr
    line1: str
    line2: Optional[str] = None
    city: str
    state: str
    postal_code: str
    country: str = "India"

class CheckoutIn(BaseModel):
    items: List[CartItemIn]
    address: AddressIn
    method: str = "razorpay"  # or 'cod'
    coupon: Optional[str] = None

class VerifyPaymentIn(BaseModel):
    order_id: str  # our internal order id
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str

# -----------------------------
# Product Seed Data (50 items)
# -----------------------------
LOOKBOOK = [
    "https://images.unsplash.com/photo-1622866654030-fb0958200023?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1609175450590-a969e9318715?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1613053342567-924891457d16?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1532074198010-97d0c3700b7a?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.pexels.com/photos/27516894/pexels-photo-27516894.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
    "https://images.pexels.com/photos/19143887/pexels-photo-19143887.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
    "https://images.pexels.com/photos/5319513/pexels-photo-5319513.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
    "https://images.pexels.com/photos/28701952/pexels-photo-28701952.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=1600",
    "https://images.unsplash.com/photo-1743463685478-d5810b3b1599?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1591758203048-4dfd0b546e01?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1628411866077-efccc1ba401f?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1732210571866-263232bff128?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1654512583166-a11eb3b8aa67?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
    "https://images.unsplash.com/photo-1583422928747-cb78b9992a17?crop=entropy&cs=srgb&fm=jpg&q=85&w=1600",
]

PRODUCT_CATALOG = [
    # Oversized Tees
    {"title": "Monolith Oversized Tee — Obsidian", "category": "tees", "price": 3499, "compare_at_price": 4999, "description": "A heavyweight statement in 320 GSM combed cotton. Cut for a deliberate drape, garment-washed for that first-day-worn softness. The Monolith is our declaration: unapologetic, quiet, powerful.", "materials": ["320 GSM combed cotton", "Reactive dye finish", "Reinforced twin-needle hems"], "fit": "Oversized. Drops one size from the shoulder. Model wears M.", "care": "Cold wash inside out. Do not tumble dry.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Obsidian","Bone"], "featured": True, "best_seller": True, "tags":["oversized","heavyweight","essential"]},
    {"title": "Sable Boxy Tee — Charcoal", "category": "tees", "price": 3299, "compare_at_price": 3999, "description": "A cropped-boxy silhouette in 280 GSM Egyptian cotton. Engineered to sit sharp, move soft. The tee that anchors a wardrobe.", "materials": ["280 GSM Egyptian cotton"], "fit": "Boxy, cropped shoulder.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Charcoal","Bone"], "featured": True, "tags":["boxy","essential"]},
    {"title": "Meridian Long-Sleeve Tee — Bone", "category": "tees", "price": 3899, "description": "A long-sleeve in 260 GSM interlock cotton. Cuffs banded. Sits like a whisper.", "materials": ["260 GSM interlock cotton"], "fit": "Regular oversize.", "care": "Cold wash.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Bone","Obsidian"], "new_drop": True, "tags":["longsleeve"]},
    {"title": "Void Heavyweight Tee — Jet", "category": "tees", "price": 3699, "description": "360 GSM. Made in Portugal. This is the tee our founders wear on Mondays.", "materials": ["360 GSM heavyweight cotton","Portugal-woven"], "fit": "Relaxed heavyweight.", "care": "Cold wash.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Jet","Bone"], "featured": True, "best_seller": True, "tags":["heavyweight"]},
    {"title": "Halcyon Pocket Tee — Ash", "category": "tees", "price": 2999, "description": "Chest pocket, twin-needle stitch, 240 GSM combed cotton. A workwear reference for the modern silhouette.", "materials": ["240 GSM combed cotton"], "fit": "Regular.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Ash","Bone","Obsidian"], "tags":["pocket"]},
    {"title": "Erasure Split-Hem Tee — Bone", "category": "tees", "price": 3399, "description": "Split side-hem, box-cut shoulder, elongated back. An editorial silhouette.", "materials": ["260 GSM combed cotton"], "fit": "Elongated.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Bone","Obsidian"], "new_drop": True, "tags":["split-hem","editorial"]},
    {"title": "Nocturne Ribbed Tee — Obsidian", "category": "tees", "price": 3199, "description": "A rib-knit tee cut close. Body-map ribbed, soft to skin.", "materials": ["220 GSM ribbed cotton"], "fit": "Slim.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Obsidian","Bone"], "tags":["ribbed"]},
    {"title": "Solstice Muscle Tee — Stone", "category": "tees", "price": 2799, "description": "Muscle silhouette in 240 GSM cotton. Cut-in armholes, dropped hem.", "materials": ["240 GSM combed cotton"], "fit": "Muscle.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Stone","Obsidian"], "tags":["muscle"]},

    # Hoodies
    {"title": "Cathedral Heavyweight Hoodie — Obsidian", "category": "hoodies", "price": 8999, "compare_at_price": 10999, "description": "500 GSM loop-back French terry. Kangaroo pocket. Metal-tipped drawcords. Built for a life spent outside comfort.", "materials": ["500 GSM French terry","Loop-back inner","Metal-tipped drawcords"], "fit": "Oversized.", "care": "Cold wash inside out. Air dry.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Obsidian","Bone","Ash"], "featured": True, "best_seller": True, "tags":["heavyweight","hoodie"]},
    {"title": "Requiem Zip Hoodie — Charcoal", "category": "hoodies", "price": 9499, "description": "Full-zip in 480 GSM brushed-back cotton. YKK zipper. Fleece-lined hood.", "materials": ["480 GSM brushed cotton","YKK zipper"], "fit": "Oversized.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Charcoal","Obsidian"], "new_drop": True, "tags":["zip","hoodie"]},
    {"title": "Ascension Pullover Hoodie — Bone", "category": "hoodies", "price": 8499, "description": "Bone pullover in 460 GSM cotton. Double-lined hood, ribbed cuffs.", "materials": ["460 GSM heavyweight cotton"], "fit": "Oversized.", "care": "Cold wash.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Bone","Obsidian"], "featured": True, "tags":["hoodie"]},
    {"title": "Silent Storm Cropped Hoodie — Ash", "category": "hoodies", "price": 7999, "description": "Cropped boxy hoodie, elevated rib, minimalist chest embroidery.", "materials": ["440 GSM cotton"], "fit": "Cropped boxy.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Ash","Obsidian"], "tags":["cropped","hoodie"]},
    {"title": "Requiem Half-Zip — Jet", "category": "hoodies", "price": 8299, "description": "Half-zip pullover with wide funnel neck. 460 GSM.", "materials": ["460 GSM cotton"], "fit": "Relaxed.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Jet","Bone"], "tags":["half-zip"]},

    # Sweatshirts
    {"title": "Vespers Crewneck — Obsidian", "category": "sweatshirts", "price": 6999, "description": "A crew in 460 GSM brushed cotton. The sweatshirt that will outlive your seasons.", "materials": ["460 GSM brushed cotton"], "fit": "Oversized.", "care": "Cold wash.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Obsidian","Bone","Ash"], "featured": True, "tags":["crewneck"]},
    {"title": "Mantra Boxy Crew — Stone", "category": "sweatshirts", "price": 6499, "description": "Boxy, cropped, minimal seam. Cut for volume.", "materials": ["440 GSM cotton"], "fit": "Boxy.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Stone","Obsidian"], "new_drop": True, "tags":["boxy"]},
    {"title": "Litany Mock-Neck Crew — Bone", "category": "sweatshirts", "price": 6799, "description": "Mock neck, drop shoulder, elongated body.", "materials": ["420 GSM cotton"], "fit": "Regular oversize.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Bone","Charcoal"], "tags":["mock-neck"]},

    # Jackets
    {"title": "Cinder Overshirt Jacket — Obsidian", "category": "jackets", "price": 12999, "compare_at_price": 15999, "description": "A shirt-jacket in 380 GSM waxed cotton. Snap-button front. Utilitarian pockets. Made in Porto.", "materials": ["380 GSM waxed cotton","Corozo buttons","Made in Porto"], "fit": "Oversized.", "care": "Wipe clean.", "sizes": ["S","M","L","XL"], "colors": ["Obsidian","Charcoal"], "featured": True, "best_seller": True, "tags":["overshirt","jacket"]},
    {"title": "Vesper Bomber — Jet", "category": "jackets", "price": 15999, "description": "Nylon bomber with ribbed cuffs. Water-repellent coating. Discreet chest embroidery.", "materials": ["Nylon shell","Ripstop lining"], "fit": "Regular.", "care": "Wipe clean.", "sizes": ["S","M","L","XL"], "colors": ["Jet"], "new_drop": True, "tags":["bomber"]},
    {"title": "Aegis Puffer — Obsidian", "category": "jackets", "price": 21999, "description": "Down puffer with recycled shell. 800-fill power down. Storm-shell finish.", "materials": ["Recycled ripstop","800-fill down"], "fit": "Regular.", "care": "Professional clean.", "sizes": ["S","M","L","XL"], "colors": ["Obsidian","Bone"], "featured": True, "tags":["puffer"]},
    {"title": "Longitude Trench — Charcoal", "category": "jackets", "price": 24999, "description": "An architectural trench, ankle length, storm shield.", "materials": ["Waxed cotton","Wool inner"], "fit": "Tall.", "care": "Professional clean.", "sizes": ["S","M","L","XL"], "colors": ["Charcoal"], "tags":["trench"]},

    # Cargo Pants
    {"title": "Meridian Cargo — Obsidian", "category": "cargos", "price": 8999, "description": "12 oz cotton twill cargo. Roomy thigh, tapered ankle. Bellows pockets.", "materials": ["12 oz cotton twill"], "fit": "Relaxed straight.", "care": "Cold wash.", "sizes": ["28","30","32","34","36"], "colors": ["Obsidian","Stone"], "featured": True, "best_seller": True, "tags":["cargo"]},
    {"title": "Rift Cargo — Stone", "category": "cargos", "price": 8499, "description": "A softer cargo silhouette in stone. Utility on your terms.", "materials": ["11 oz cotton twill"], "fit": "Regular.", "care": "Cold wash.", "sizes": ["28","30","32","34"], "colors": ["Stone","Obsidian"], "tags":["cargo"]},
    {"title": "Anchor Cargo Short — Ash", "category": "cargos", "price": 5499, "description": "A knee-length cargo short. Anchored, quiet, versatile.", "materials": ["10 oz cotton"], "fit": "Regular.", "care": "Cold wash.", "sizes": ["28","30","32","34"], "colors": ["Ash","Obsidian"], "new_drop": True, "tags":["short","cargo"]},

    # Joggers
    {"title": "Silent Jogger — Obsidian", "category": "joggers", "price": 6499, "description": "Elevated jogger in 440 GSM brushed fleece.", "materials": ["440 GSM brushed fleece"], "fit": "Tapered.", "care": "Cold wash.", "sizes": ["S","M","L","XL","XXL"], "colors": ["Obsidian","Bone","Charcoal"], "featured": True, "best_seller": True, "tags":["jogger"]},
    {"title": "Vellum Wide-Leg Sweat — Bone", "category": "joggers", "price": 6999, "description": "Wide-leg sweatpant. Elongated and sculpted.", "materials": ["420 GSM cotton fleece"], "fit": "Wide-leg.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Bone","Obsidian"], "new_drop": True, "tags":["wide-leg"]},
    {"title": "Kore Tapered Track Pant — Ash", "category": "joggers", "price": 6799, "description": "Nylon track pant with satin side panel. Sport-luxury.", "materials": ["Nylon shell","Satin trim"], "fit": "Tapered.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Ash","Obsidian"], "tags":["track"]},

    # Denim
    {"title": "Obsidian Selvedge Denim — Raw", "category": "denim", "price": 12499, "description": "14 oz Japanese selvedge. Rigid raw indigo. Straight leg.", "materials": ["14 oz Japanese selvedge"], "fit": "Straight.", "care": "Cold wash after 6 months.", "sizes": ["28","30","32","34","36"], "colors": ["Raw indigo"], "featured": True, "tags":["selvedge","denim"]},
    {"title": "Rift Loose Denim — Onyx", "category": "denim", "price": 9999, "description": "Loose-cut denim, garment-washed to a deep onyx tone.", "materials": ["12 oz cotton denim"], "fit": "Loose.", "care": "Cold wash.", "sizes": ["28","30","32","34","36"], "colors": ["Onyx"], "new_drop": True, "tags":["denim","loose"]},
    {"title": "Cloud Wide Denim — Bone", "category": "denim", "price": 10499, "description": "Wide-leg bone denim. Ecru-toned. A canvas.", "materials": ["12 oz cotton denim"], "fit": "Wide.", "care": "Cold wash.", "sizes": ["28","30","32","34"], "colors": ["Bone"], "tags":["denim","wide"]},

    # Caps
    {"title": "HR Signature Cap — Obsidian", "category": "caps", "price": 2499, "description": "The signature cap. Embroidered HR monogram. Curved brim. 100% cotton twill.", "materials": ["100% cotton twill","Metal buckle strap"], "fit": "Adjustable.", "care": "Wipe clean.", "sizes": ["One Size"], "colors": ["Obsidian"], "featured": True, "best_seller": True, "tags":["cap","signature"]},
    {"title": "HR Flat-Brim Cap — Jet", "category": "caps", "price": 2799, "description": "Structured six-panel with flat brim. Woven HR patch.", "materials": ["100% cotton","Woven patch"], "fit": "Adjustable.", "care": "Wipe clean.", "sizes": ["One Size"], "colors": ["Jet"], "new_drop": True, "tags":["cap","flat-brim"]},
    {"title": "HR Beanie — Charcoal", "category": "caps", "price": 1999, "description": "Fine merino beanie. Cuffed. Understated HR tag.", "materials": ["Merino wool"], "fit": "One size.", "care": "Hand wash.", "sizes": ["One Size"], "colors": ["Charcoal","Bone","Obsidian"], "tags":["beanie"]},
    {"title": "HR Bucket Hat — Obsidian", "category": "caps", "price": 2999, "description": "Wide-brim bucket with reinforced eyelets.", "materials": ["Cotton canvas"], "fit": "One size.", "care": "Wipe clean.", "sizes": ["One Size"], "colors": ["Obsidian","Bone"], "tags":["bucket"]},

    # Accessories
    {"title": "HR Tote — Bone", "category": "accessories", "price": 2499, "description": "Heavyweight canvas tote. Reinforced strap. HR embroidered.", "materials": ["16 oz canvas"], "fit": "One size.", "care": "Spot clean.", "sizes": ["One Size"], "colors": ["Bone","Obsidian"], "tags":["tote","bag"]},
    {"title": "HR Crossbody — Obsidian", "category": "accessories", "price": 4999, "description": "Nylon crossbody with adjustable strap. Water-resistant.", "materials": ["Nylon","YKK zip"], "fit": "One size.", "care": "Wipe clean.", "sizes": ["One Size"], "colors": ["Obsidian"], "featured": True, "tags":["bag","crossbody"]},
    {"title": "HR Weekender Duffle — Jet", "category": "accessories", "price": 8999, "description": "Weekender in waxed canvas with leather trim.", "materials": ["Waxed canvas","Leather trim"], "fit": "One size.", "care": "Wipe clean.", "sizes": ["One Size"], "colors": ["Jet"], "tags":["duffle","bag"]},
    {"title": "HR Socks — Bone (3-pack)", "category": "accessories", "price": 1499, "description": "Ribbed crew socks, bone. Set of three.", "materials": ["Combed cotton blend"], "fit": "M/L.", "care": "Cold wash.", "sizes": ["M","L"], "colors": ["Bone","Obsidian"], "tags":["socks"]},
    {"title": "HR Belt — Obsidian Leather", "category": "accessories", "price": 5999, "description": "Full-grain Italian leather belt. Brushed metal buckle.", "materials": ["Full-grain leather"], "fit": "Adjustable.", "care": "Leather conditioner.", "sizes": ["S","M","L"], "colors": ["Obsidian"], "tags":["belt"]},
    {"title": "HR Silk Scarf — Bone", "category": "accessories", "price": 3999, "description": "100% mulberry silk scarf. Hand-rolled edges.", "materials": ["100% mulberry silk"], "fit": "One size.", "care": "Dry clean.", "sizes": ["One Size"], "colors": ["Bone"], "new_drop": True, "tags":["scarf"]},

    # Additional pieces to reach 50
    {"title": "Threshold Overshirt — Stone", "category": "jackets", "price": 11999, "description": "A lightweight overshirt in stone. Piped seams.", "materials": ["380 GSM cotton"], "fit": "Oversized.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Stone","Obsidian"], "tags":["overshirt"]},
    {"title": "Requiem Hooded Vest — Obsidian", "category": "jackets", "price": 8499, "description": "Padded hooded vest, midweight.", "materials": ["Recycled shell","Down inner"], "fit": "Regular.", "care": "Wipe.", "sizes": ["S","M","L","XL"], "colors": ["Obsidian"], "tags":["vest"]},
    {"title": "Mantle Wool Coat — Charcoal", "category": "jackets", "price": 29999, "description": "A tailored wool coat, floor-length. Made in Italy.", "materials": ["100% wool","Made in Italy"], "fit": "Tailored.", "care": "Professional clean.", "sizes": ["S","M","L","XL"], "colors": ["Charcoal"], "featured": True, "tags":["coat","luxury"]},
    {"title": "Silhouette Straight Trouser — Obsidian", "category": "cargos", "price": 7999, "description": "A tailored straight trouser with soft drape.", "materials": ["Wool-blend"], "fit": "Straight.", "care": "Dry clean.", "sizes": ["28","30","32","34"], "colors": ["Obsidian","Charcoal"], "tags":["trouser"]},
    {"title": "Verse Utility Short — Obsidian", "category": "cargos", "price": 4999, "description": "Short utility pant.", "materials": ["Cotton twill"], "fit": "Regular.", "care": "Cold wash.", "sizes": ["28","30","32","34"], "colors": ["Obsidian","Stone"], "tags":["short"]},
    {"title": "Silent Slip Tank — Bone", "category": "tees", "price": 2499, "description": "A ribbed tank in bone.", "materials": ["220 GSM ribbed cotton"], "fit": "Slim.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Bone","Obsidian"], "tags":["tank"]},
    {"title": "Nocturne Overcoat — Obsidian", "category": "jackets", "price": 22999, "description": "A knee-length overcoat.", "materials": ["Wool blend"], "fit": "Regular.", "care": "Dry clean.", "sizes": ["S","M","L","XL"], "colors": ["Obsidian"], "tags":["overcoat"]},
    {"title": "Mantra Zip Sweat — Charcoal", "category": "sweatshirts", "price": 6799, "description": "Zipped crewneck sweat.", "materials": ["420 GSM cotton"], "fit": "Regular.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Charcoal","Obsidian"], "tags":["zip"]},
    {"title": "Vellum Wide Pant — Stone", "category": "joggers", "price": 6499, "description": "Wide-leg lounge pant.", "materials": ["380 GSM cotton"], "fit": "Wide.", "care": "Cold wash.", "sizes": ["S","M","L","XL"], "colors": ["Stone","Obsidian"], "tags":["pant"]},
    {"title": "HR Card Holder — Obsidian Leather", "category": "accessories", "price": 3499, "description": "Slim leather card holder.", "materials": ["Full-grain leather"], "fit": "One size.", "care": "Wipe.", "sizes": ["One Size"], "colors": ["Obsidian"], "tags":["wallet"]},
    {"title": "HR Chain — Silver", "category": "accessories", "price": 6999, "description": "Sterling silver chain, brushed finish.", "materials": ["925 sterling silver"], "fit": "One size.", "care": "Polish cloth.", "sizes": ["One Size"], "colors": ["Silver"], "tags":["jewelry"]},
]

def slug_for(title: str) -> str:
    return slugify(title)

async def seed_products():
    count = await db.products.count_documents({})
    if count >= 45:
        return
    await db.products.delete_many({})
    now = now_utc()
    docs = []
    for i, p in enumerate(PRODUCT_CATALOG):
        # rotate images from lookbook — first image is hero
        img_start = (i * 2) % len(LOOKBOOK)
        images = [LOOKBOOK[img_start], LOOKBOOK[(img_start+1) % len(LOOKBOOK)], LOOKBOOK[(img_start+3) % len(LOOKBOOK)]]
        doc = {
            "title": p["title"],
            "slug": slug_for(p["title"]),
            "category": p["category"],
            "price": p["price"],
            "compare_at_price": p.get("compare_at_price"),
            "description": p["description"],
            "materials": p.get("materials", []),
            "fit": p.get("fit"),
            "care": p.get("care"),
            "sizes": p.get("sizes", []),
            "colors": p.get("colors", []),
            "images": images,
            "tags": p.get("tags", []),
            "stock": 100,
            "featured": p.get("featured", False),
            "new_drop": p.get("new_drop", False),
            "best_seller": p.get("best_seller", False),
            "rating_avg": round(4.4 + (i % 6) * 0.1, 1),
            "rating_count": 12 + i * 3,
            "created_at": now,
        }
        docs.append(doc)
    await db.products.insert_many(docs)
    log.info(f"Seeded {len(docs)} products")

# -----------------------------
# Startup
# -----------------------------
@app.on_event("startup")
async def startup():
    try:
        await db.users.create_index("email", unique=True)
        await db.products.create_index("slug", unique=True)
        await db.products.create_index("category")
        await db.orders.create_index("user_id")
        await db.reviews.create_index("product_id")
        await db.newsletter.create_index("email", unique=True)
        await db.login_attempts.create_index("identifier")

        # Seed admin
        admin_email = os.environ.get("ADMIN_EMAIL", "admin@wearhr.in")
        admin_password = os.environ.get("ADMIN_PASSWORD", "Wearhr@2026")
        existing = await db.users.find_one({"email": admin_email})
        if existing is None:
            await db.users.insert_one({
                "email": admin_email,
                "password_hash": hash_password(admin_password),
                "name": "WEARHR Admin",
                "role": "admin",
                "created_at": now_utc(),
            })
            log.info("Seeded admin user")
        else:
            if not verify_password(admin_password, existing["password_hash"]):
                await db.users.update_one({"email": admin_email}, {"$set": {"password_hash": hash_password(admin_password)}})
                log.info("Updated admin password")

        await seed_products()
        log.info("Startup complete — database ready.")
    except Exception:
        # Never let a Mongo hiccup at boot take the whole API down —
        # log it loudly and keep serving; endpoints that need the DB
        # will surface a clear error instead of the server not
        # existing at all.
        log.exception(
            "Startup DB initialization failed. The API will still boot, "
            "but check MONGO_URL — nothing will work until Mongo is reachable."
        )

# -----------------------------
# Health
# -----------------------------
@app.get("/api/health")
async def health():
    mongo_ok = True
    mongo_error = None
    try:
        await client.admin.command("ping")
    except Exception as e:
        mongo_ok = False
        mongo_error = str(e)
    return {
        "ok": mongo_ok,
        "mongo": "connected" if mongo_ok else f"unreachable: {mongo_error}",
        "razorpay_configured": bool(RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET),
        "product_count": await db.products.count_documents({}) if mongo_ok else None,
    }

# -----------------------------
# Auth
# -----------------------------
@app.post("/api/auth/register")
async def register(body: RegisterIn):
    email = body.email.lower()
    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    doc = {
        "email": email,
        "password_hash": hash_password(body.password),
        "name": body.name or email.split("@")[0],
        "role": "customer",
        "created_at": now_utc(),
    }
    r = await db.users.insert_one(doc)
    token = create_access_token(str(r.inserted_id), email, "customer")
    return {"token": token, "user": {"id": str(r.inserted_id), "email": email, "name": doc["name"], "role": "customer"}}

@app.post("/api/auth/login")
async def login(body: LoginIn):
    email = body.email.lower()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(str(user["_id"]), email, user.get("role", "customer"))
    return {"token": token, "user": {"id": str(user["_id"]), "email": email, "name": user.get("name"), "role": user.get("role", "customer")}}

@app.get("/api/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return user

# -----------------------------
# Products
# -----------------------------
@app.get("/api/products")
async def list_products(
    category: Optional[str] = None,
    featured: Optional[bool] = None,
    new_drop: Optional[bool] = None,
    best_seller: Optional[bool] = None,
    q: Optional[str] = None,
    limit: int = 60,
    skip: int = 0,
    sort: str = "featured",  # featured | price_asc | price_desc | newest
):
    query: dict = {}
    if category:
        query["category"] = category
    if featured is not None:
        query["featured"] = featured
    if new_drop is not None:
        query["new_drop"] = new_drop
    if best_seller is not None:
        query["best_seller"] = best_seller
    if q:
        query["$or"] = [
            {"title": {"$regex": q, "$options": "i"}},
            {"tags": {"$regex": q, "$options": "i"}},
            {"category": {"$regex": q, "$options": "i"}},
        ]
    sort_spec: List[Any] = [("featured", -1), ("created_at", -1)]
    if sort == "price_asc":
        sort_spec = [("price", 1)]
    elif sort == "price_desc":
        sort_spec = [("price", -1)]
    elif sort == "newest":
        sort_spec = [("created_at", -1)]

    cursor = db.products.find(query).sort(sort_spec).skip(skip).limit(limit)
    items = [serialize_doc(d) async for d in cursor]
    total = await db.products.count_documents(query)
    return {"items": items, "total": total}

@app.get("/api/products/{slug}")
async def get_product(slug: str):
    doc = await db.products.find_one({"slug": slug})
    if not doc:
        raise HTTPException(status_code=404, detail="Product not found")
    # related
    related_cursor = db.products.find({"category": doc["category"], "_id": {"$ne": doc["_id"]}}).limit(4)
    related = [serialize_doc(d) async for d in related_cursor]
    return {"product": serialize_doc(doc), "related": related}

@app.get("/api/categories")
async def categories():
    cats = await db.products.distinct("category")
    return {"items": sorted(cats)}

# -----------------------------
# Wishlist
# -----------------------------
@app.get("/api/wishlist")
async def get_wishlist(user: dict = Depends(get_current_user)):
    docs = db.wishlist.find({"user_id": user["id"]})
    items = [serialize_doc(d) async for d in docs]
    return {"items": items}

@app.post("/api/wishlist")
async def add_wishlist(body: WishlistIn, user: dict = Depends(get_current_user)):
    existing = await db.wishlist.find_one({"user_id": user["id"], "product_id": body.product_id})
    if existing:
        return {"ok": True}
    await db.wishlist.insert_one({"user_id": user["id"], "product_id": body.product_id, "created_at": now_utc()})
    return {"ok": True}

@app.delete("/api/wishlist/{product_id}")
async def remove_wishlist(product_id: str, user: dict = Depends(get_current_user)):
    await db.wishlist.delete_one({"user_id": user["id"], "product_id": product_id})
    return {"ok": True}

# -----------------------------
# Newsletter
# -----------------------------
@app.post("/api/newsletter")
async def subscribe(body: NewsletterIn):
    try:
        await db.newsletter.insert_one({"email": body.email.lower(), "created_at": now_utc()})
    except Exception:
        pass
    return {"ok": True}

# -----------------------------
# Reviews
# -----------------------------
@app.get("/api/reviews/{product_id}")
async def get_reviews(product_id: str):
    cursor = db.reviews.find({"product_id": product_id}).sort([("created_at", -1)]).limit(20)
    items = [serialize_doc(d) async for d in cursor]
    return {"items": items}

@app.post("/api/reviews")
async def add_review(body: ReviewIn, user: dict = Depends(get_current_user)):
    doc = {
        "user_id": user["id"],
        "user_name": user.get("name"),
        "product_id": body.product_id,
        "rating": body.rating,
        "title": body.title,
        "body": body.body,
        "created_at": now_utc(),
    }
    r = await db.reviews.insert_one(doc)
    return {"id": str(r.inserted_id)}

# -----------------------------
# Orders / Checkout
# -----------------------------
async def compute_totals(items: List[CartItemIn]):
    subtotal = 0
    line_items = []
    for it in items:
        p = await db.products.find_one({"_id": ObjectId(it.product_id)})
        if not p:
            raise HTTPException(status_code=400, detail=f"Product not found: {it.product_id}")
        line_total = p["price"] * it.qty
        subtotal += line_total
        line_items.append({
            "product_id": str(p["_id"]),
            "title": p["title"],
            "slug": p["slug"],
            "image": (p.get("images") or [None])[0],
            "size": it.size,
            "color": it.color,
            "qty": it.qty,
            "unit_price": p["price"],
            "line_total": line_total,
        })
    shipping = 0 if subtotal >= 4999 else 199
    tax = round(subtotal * 0.05)  # 5% GST simplified
    total = subtotal + shipping + tax
    return line_items, subtotal, shipping, tax, total

@app.post("/api/orders")
async def create_order(body: CheckoutIn, request: Request):
    user = await optional_user(request)
    line_items, subtotal, shipping, tax, total = await compute_totals(body.items)

    order_doc = {
        "user_id": user["id"] if user else None,
        "email": body.address.email,
        "items": line_items,
        "subtotal": subtotal,
        "shipping": shipping,
        "tax": tax,
        "total": total,
        "address": body.address.dict(),
        "method": body.method,
        "coupon": body.coupon,
        "status": "created",
        "payment_status": "pending",
        "created_at": now_utc(),
    }

    if body.method == "razorpay":
        if rzp is None or not RAZORPAY_KEY_ID:
            raise HTTPException(status_code=503, detail="Online payment isn't configured yet. Please choose Cash on Delivery or try again shortly.")
        # Create razorpay order
        try:
            rzp_order = rzp.order.create({
                "amount": total * 100,
                "currency": "INR",
                "payment_capture": 1,
            })
            order_doc["razorpay_order_id"] = rzp_order["id"]
        except Exception as e:
            log.exception("Razorpay order create failed")
            raise HTTPException(status_code=502, detail=f"Payment gateway error: {str(e)}")

    r = await db.orders.insert_one(order_doc)
    order_doc["_id"] = r.inserted_id
    return {
        "order": serialize_doc(order_doc),
        "razorpay_key_id": RAZORPAY_KEY_ID if body.method == "razorpay" else None,
    }

@app.post("/api/orders/verify")
async def verify_payment(body: VerifyPaymentIn):
    # Verify signature
    generated_signature = hmac.new(
        RAZORPAY_KEY_SECRET.encode("utf-8"),
        f"{body.razorpay_order_id}|{body.razorpay_payment_id}".encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(generated_signature, body.razorpay_signature):
        await db.orders.update_one({"_id": ObjectId(body.order_id)}, {"$set": {"payment_status": "failed"}})
        raise HTTPException(status_code=400, detail="Invalid payment signature")

    await db.orders.update_one(
        {"_id": ObjectId(body.order_id)},
        {"$set": {
            "payment_status": "paid",
            "status": "confirmed",
            "razorpay_payment_id": body.razorpay_payment_id,
            "razorpay_signature": body.razorpay_signature,
            "paid_at": now_utc(),
        }}
    )
    order = await db.orders.find_one({"_id": ObjectId(body.order_id)})
    return {"ok": True, "order": serialize_doc(order)}

@app.get("/api/orders/{order_id}")
async def get_order(order_id: str):
    try:
        oid = ObjectId(order_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid order id")
    order = await db.orders.find_one({"_id": oid})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return {"order": serialize_doc(order)}

@app.get("/api/orders")
async def list_my_orders(user: dict = Depends(get_current_user)):
    cursor = db.orders.find({"user_id": user["id"]}).sort([("created_at", -1)]).limit(50)
    items = [serialize_doc(d) async for d in cursor]
    return {"items": items}

# -----------------------------
# Admin
# -----------------------------
@app.get("/api/admin/users")
async def admin_list_users(user: dict = Depends(require_admin)):
    cursor = db.users.find({}, {"password_hash": 0}).sort([("created_at", -1)]).limit(500)
    items = [serialize_doc(d) async for d in cursor]
    return {"items": items, "total": len(items)}

@app.get("/api/admin/orders")
async def admin_orders(user: dict = Depends(require_admin)):
    cursor = db.orders.find({}).sort([("created_at", -1)]).limit(200)
    return {"items": [serialize_doc(d) async for d in cursor]}

@app.get("/api/admin/stats")
async def admin_stats(user: dict = Depends(require_admin)):
    total_orders = await db.orders.count_documents({})
    paid_orders = await db.orders.count_documents({"payment_status": "paid"})
    total_products = await db.products.count_documents({})
    total_users = await db.users.count_documents({})
    revenue_pipeline = [
        {"$match": {"payment_status": "paid"}},
        {"$group": {"_id": None, "total": {"$sum": "$total"}}},
    ]
    revenue = 0
    async for r in db.orders.aggregate(revenue_pipeline):
        revenue = r.get("total", 0)
    return {
        "orders": total_orders,
        "paid": paid_orders,
        "products": total_products,
        "users": total_users,
        "revenue": revenue,
    }

@app.get("/api/admin/products")
async def admin_list_products(
    q: Optional[str] = None,
    category: Optional[str] = None,
    limit: int = 200,
    skip: int = 0,
    user: dict = Depends(require_admin),
):
    query: dict = {}
    if category:
        query["category"] = category
    if q:
        query["title"] = {"$regex": q, "$options": "i"}
    cursor = db.products.find(query).sort([("created_at", -1)]).skip(skip).limit(limit)
    items = [serialize_doc(d) async for d in cursor]
    total = await db.products.count_documents(query)
    return {"items": items, "total": total}

@app.post("/api/admin/products")
async def create_product(body: ProductIn, user: dict = Depends(require_admin)):
    doc = body.dict()
    doc["slug"] = slug_for(doc["title"])
    doc["created_at"] = now_utc()
    doc["rating_avg"] = 0
    doc["rating_count"] = 0
    try:
        r = await db.products.insert_one(doc)
    except Exception as e:
        raise HTTPException(status_code=409, detail=f"A product with a similar title/slug already exists ({e})")
    return {"id": str(r.inserted_id), "slug": doc["slug"]}

@app.put("/api/admin/products/{product_id}")
async def update_product(product_id: str, body: ProductIn, user: dict = Depends(require_admin)):
    try:
        oid = ObjectId(product_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid product id")
    update = body.dict()
    update["slug"] = slug_for(update["title"])
    result = await db.products.update_one({"_id": oid}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"ok": True, "slug": update["slug"]}

@app.delete("/api/admin/products/{product_id}")
async def delete_product(product_id: str, user: dict = Depends(require_admin)):
    try:
        oid = ObjectId(product_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid product id")
    result = await db.products.delete_one({"_id": oid})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"ok": True}

@app.get("/api/sitemap-products.xml")
async def sitemap_products():
    from fastapi.responses import Response
    cursor = db.products.find({}, {"slug": 1})
    urls = []
    async for d in cursor:
        urls.append(f"<url><loc>https://wearhr.in/product/{d['slug']}</loc><priority>0.8</priority></url>")
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        + "".join(urls) +
        "</urlset>"
    )
    return Response(content=xml, media_type="application/xml")

# Root
@app.get("/api")
async def api_root():
    return {"service": "WEARHR API", "version": "1.0.0"}
