# WEARHR — Setup & Troubleshooting

This covers exactly what was fixed in this pass and how to get the site
fully working end-to-end (products, admin, Razorpay).

## What was actually broken

Your screenshots showed: empty/"not found" product pages, a generic
host-level 404 on some routes, and a loading screen that never resolved
on a slow connection. All four trace back to one or two root causes:

1. **The backend was crashing at startup.** `server.py` used
   `os.environ["MONGO_URL"]` (and similarly for `DB_NAME`, `JWT_SECRET`,
   `RAZORPAY_KEY_ID/SECRET`) — if **any one** of these wasn't set in your
   deployment, Python throws `KeyError` at import time and the **entire
   API process refuses to start.** Every page that needs data (Home,
   Shop, Product pages) then has nothing to load, which is exactly the
   "not found" / empty behavior you saw. This is now fixed — the app
   boots with safe fallbacks and just logs a warning for anything
   missing, instead of dying.
2. **No SPA fallback on some hosts.** If you deep-link to `/shop/tees`
   or refresh on a product page, static hosts need to be told "serve
   index.html for every path — let React Router handle it." Without
   that config, the host itself returns its own 404 page (the
   skateboard graphic you saw is a generic hosting-platform 404, not
   your app). Config files for this are now included: `_redirects`
   (Netlify) and `vercel.json` (Vercel). If you're self-hosting, use the
   included `serve.js`.
3. **No error boundary + no static pre-mount splash.** Any single
   runtime error anywhere in the React tree used to blank the whole
   page with no explanation, and on a slow connection there was nothing
   to look at until the full JS bundle downloaded. Both are fixed: a
   global error boundary now catches runtime errors and shows a
   "Reload" screen instead of freezing, and `index.html` now paints an
   instant branded "WEARHR — Wear Your Ambition" splash before React
   even loads, handing off seamlessly to the cinematic counter loader.

## Required environment variables

**Backend** — copy `backend/.env.example` to `backend/.env` and fill in:

| Variable | Required for | Notes |
|---|---|---|
| `MONGO_URL` | everything | MongoDB Atlas free tier works fine |
| `DB_NAME` | everything | e.g. `wearhr` |
| `JWT_SECRET` | login sessions surviving restarts | any long random string |
| `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` | real online payments | from your Razorpay dashboard |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | admin login | defaults to `admin@wearhr.in` / `Wearhr@2026` — **change this** |

**Frontend** — copy `frontend/.env.example` to `frontend/.env`:

| Variable | Notes |
|---|---|
| `REACT_APP_BACKEND_URL` | Full base URL of your deployed backend, no trailing slash, no `/api` |

## Running locally

```bash
# Backend
cd backend
pip install -r requirements.txt
cp .env.example .env   # then edit .env with real values
uvicorn server:app --reload --port 8000

# Frontend (new terminal)
cd frontend
cp .env.example .env   # then edit .env
npm install
npm start
```

Visit `http://localhost:3000`. Check `http://localhost:8000/api/health`
directly in a browser at any time — it now reports Mongo connectivity,
Razorpay configuration status, and the live product count, so you can
tell in one request whether the backend is actually healthy.

## Admin panel — managing products

1. Sign in at `/login` with your admin email/password.
2. Navigate directly to `/admin`.
3. The **Products** tab now has full CRUD: search, add new product,
   edit price/stock/images/description/sizes/colors inline, and delete
   with a confirmation step. This calls the existing (and one new)
   backend endpoints:
   - `GET /api/admin/products` (new — paginated listing for the panel)
   - `POST /api/admin/products` (create)
   - `PUT /api/admin/products/{id}` (update — price, stock, everything)
   - `DELETE /api/admin/products/{id}` (delete)

All of these require an admin-role JWT (handled automatically once
you're logged in as the seeded admin account).

## Razorpay

The checkout flow itself was already correctly wired (server-side order
creation → Razorpay Checkout.js → signature verification on your
backend). What's new:
- If `RAZORPAY_KEY_ID`/`SECRET` aren't set, the API now returns a clear
  "payment isn't configured yet" message instead of a confusing 500, and
  Cash on Delivery still works.
- If the Razorpay `checkout.js` script fails to load (ad-blocker, very
  slow connection), the frontend now shows an explicit message instead
  of throwing a blank error when you click Pay.

## Deploying

Whatever host you use, make sure:
- The backend's `.env` is fully filled in (see table above).
- The frontend's `REACT_APP_BACKEND_URL` points at the **public** URL
  of that backend (not `localhost`).
- Your host serves `index.html` for unknown paths (Netlify/Vercel: the
  included config files handle this automatically; anything else: use
  `serve.js` or your host's SPA-fallback setting).
